#Requires -Version 5.1
<#
.SYNOPSIS
    Setup Cloudflare Named Tunnel (URL Permanen) untuk MT5 Trading Server.
.DESCRIPTION
    Prasyarat:
      1. Akun Cloudflare gratis  ->  https://dash.cloudflare.com/sign-up
      2. Domain sudah di-add ke Cloudflare (ubah nameserver domain ke Cloudflare)
      3. cloudflared.exe sudah ada (jalankan setup-cloudflare.ps1 dulu)
.PARAMETER TunnelName
    Nama tunnel (bebas, contoh: mt5bot)
.PARAMETER Subdomain
    Subdomain + domain kamu, contoh: mt5.namadomain.com
.PARAMETER LocalPort
    Port Node.js (default 3000)
.EXAMPLE
    .\setup-named-tunnel.ps1 -TunnelName "mt5bot" -Subdomain "mt5.namadomain.com"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$TunnelName,
    [Parameter(Mandatory)][string]$Subdomain,
    [int]$LocalPort = 3000
)

$ErrorActionPreference = 'Stop'

$cloudflaredDir = "$env:LOCALAPPDATA\cloudflared"
$cloudflaredExe = "$cloudflaredDir\cloudflared.exe"
$configFile     = "$cloudflaredDir\config.yml"
$taskName       = "CloudflaredMT5Named"

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  MT5 — Cloudflare Named Tunnel Setup" -ForegroundColor Cyan
Write-Host "============================================`n" -ForegroundColor Cyan

# ── Cek cloudflared ada ───────────────────────────────────────────────────────
if(-not (Test-Path $cloudflaredExe)) {
    Write-Host "[!] cloudflared.exe tidak ditemukan." -ForegroundColor Red
    Write-Host "    Jalankan setup-cloudflare.ps1 terlebih dahulu." -ForegroundColor Yellow
    exit 1
}

# ── Step 1: Login ke Cloudflare (buka browser sekali saja) ───────────────────
Write-Host "[1/4] Login ke Cloudflare..." -ForegroundColor Yellow
Write-Host "      Browser akan terbuka. Login & pilih domain kamu." -ForegroundColor Gray
Write-Host "      (Jika sudah pernah login, langkah ini otomatis terlewati)`n"

& $cloudflaredExe tunnel login
if($LASTEXITCODE -ne 0) {
    Write-Host "[!] Login gagal. Coba lagi." -ForegroundColor Red; exit 1
}
Write-Host "      Login berhasil!`n" -ForegroundColor Green

# ── Step 2: Buat tunnel ───────────────────────────────────────────────────────
Write-Host "[2/4] Buat tunnel '$TunnelName'..." -ForegroundColor Yellow

# Cek apakah tunnel sudah ada
$existingTunnels = & $cloudflaredExe tunnel list 2>&1
if($existingTunnels -match $TunnelName) {
    Write-Host "      Tunnel '$TunnelName' sudah ada, dipakai ulang." -ForegroundColor Green
} else {
    & $cloudflaredExe tunnel create $TunnelName
    if($LASTEXITCODE -ne 0) {
        Write-Host "[!] Gagal membuat tunnel." -ForegroundColor Red; exit 1
    }
    Write-Host "      Tunnel '$TunnelName' berhasil dibuat!`n" -ForegroundColor Green
}

# Ambil Tunnel ID
$tunnelInfo = & $cloudflaredExe tunnel info $TunnelName 2>&1 | Out-String
$tunnelId   = ($tunnelInfo | Select-String -Pattern '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}').Matches[0].Value
Write-Host "      Tunnel ID: $tunnelId" -ForegroundColor Gray

# ── Step 3: Buat config.yml ───────────────────────────────────────────────────
Write-Host "`n[3/4] Membuat file konfigurasi..." -ForegroundColor Yellow

$configContent = @"
tunnel: $tunnelId
credentials-file: $env:USERPROFILE\.cloudflared\$tunnelId.json

ingress:
  - hostname: $Subdomain
    service: http://localhost:$LocalPort
  - service: http_status:404
"@

Set-Content -Path $configFile -Value $configContent -Encoding UTF8
Write-Host "      Config tersimpan: $configFile" -ForegroundColor Green

# ── Step 4: Tambah DNS record ─────────────────────────────────────────────────
Write-Host "`n[4/4] Tambah DNS record (CNAME)..." -ForegroundColor Yellow
& $cloudflaredExe tunnel route dns $TunnelName $Subdomain
if($LASTEXITCODE -ne 0) {
    Write-Host "[!] Gagal menambah DNS. Tambahkan manual di Cloudflare Dashboard:"  -ForegroundColor Yellow
    Write-Host "    Type : CNAME"
    Write-Host "    Name : $($Subdomain.Split('.')[0])"
    Write-Host "    Value: $tunnelId.cfargotunnel.com"
    Write-Host "    Proxy: ON (orange cloud)"
} else {
    Write-Host "      DNS record berhasil ditambahkan!`n" -ForegroundColor Green
}

# ── Daftarkan ke Task Scheduler ───────────────────────────────────────────────
Write-Host "`nDaftarkan sebagai Windows Scheduled Task (auto-start saat login)?" -ForegroundColor Yellow
$choice = Read-Host "(y/N)"

if($choice -in 'y','Y') {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

    $action   = New-ScheduledTaskAction `
                    -Execute         $cloudflaredExe `
                    -Argument        "tunnel --config `"$configFile`" run $TunnelName" `
                    -WorkingDirectory $cloudflaredDir

    $trigger  = New-ScheduledTaskTrigger -AtLogOn

    $settings = New-ScheduledTaskSettingsSet `
                    -ExecutionTimeLimit        ([TimeSpan]::Zero) `
                    -RestartCount              5 `
                    -RestartInterval           (New-TimeSpan -Minutes 1) `
                    -StartWhenAvailable        $true `
                    -RunOnlyIfNetworkAvailable $true

    Register-ScheduledTask `
        -TaskName  $taskName `
        -Action    $action `
        -Trigger   $trigger `
        -Settings  $settings `
        -RunLevel  Limited `
        -Force | Out-Null

    Start-ScheduledTask -TaskName $taskName
    Start-Sleep -Seconds 3

    $state = (Get-ScheduledTask -TaskName $taskName).State
    Write-Host "  Task '$taskName' terdaftar. Status: $state" -ForegroundColor Green
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  SELESAI! URL Permanen kamu:" -ForegroundColor Cyan
Write-Host "  https://$Subdomain" -ForegroundColor White
Write-Host "  https://$Subdomain/dashboard.html" -ForegroundColor White
Write-Host "============================================`n" -ForegroundColor Cyan

Write-Host "  Perintah berguna:" -ForegroundColor Gray
Write-Host "  Test tunnel  : & '$cloudflaredExe' tunnel --config '$configFile' run $TunnelName"
Write-Host "  Lihat tunnel : & '$cloudflaredExe' tunnel list"
Write-Host "  Hapus tunnel : & '$cloudflaredExe' tunnel delete $TunnelName`n"
