#Requires -Version 5.1
$ErrorActionPreference = 'Stop'

$baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$inputFile = Join-Path $baseDir 'start-dashboard.ps1'
$outputFile = Join-Path $baseDir 'XAU-Dashboard-Launcher.exe'

if (-not (Test-Path $inputFile)) {
    throw "Input file tidak ditemukan: $inputFile"
}

if (-not (Get-Module -ListAvailable -Name ps2exe)) {
    Install-Module -Name ps2exe -Scope CurrentUser -Force -AllowClobber
}

Import-Module ps2exe -ErrorAction Stop

Invoke-ps2exe -inputFile $inputFile -outputFile $outputFile -noConsole -STA -title 'XAU Dashboard Launcher'

Write-Host "EXE berhasil dibuat:" -ForegroundColor Green
Write-Host $outputFile -ForegroundColor Cyan
