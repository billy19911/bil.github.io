@echo off
cd /d "%~dp0"
wscript //nologo "%~dp0START-GUI.vbs"
exit /b 0
