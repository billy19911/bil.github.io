Option Explicit

Dim shell, fso, scriptPath, cmd
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

scriptPath = fso.BuildPath(fso.GetParentFolderName(WScript.ScriptFullName), "start-dashboard.ps1")

If Not fso.FileExists(scriptPath) Then
  MsgBox "File tidak ditemukan: " & scriptPath, vbCritical, "XAU Monster Launcher"
  WScript.Quit 1
End If

cmd = "powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & scriptPath & """"
shell.Run cmd, 0, False
