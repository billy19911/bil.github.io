# XAU Monster Dashboard - Installation and Operations Guide

This guide explains how to install, configure, run, and maintain the MT5 Dashboard stack for local use and customer distribution.

## 1. What This Package Contains

- MT5 EA(s) that send status, reports, and settings to a local API server.
- Node.js API server and web dashboard.
- Cloudflare Pages deployment flow (manual and automatic).
- Launcher (`start-dashboard.ps1`) for one-click operations.

Important:

- If you convert launcher to EXE, that EXE is only the launcher wrapper.
- Runtime files (`server.js`, `public/*`, `package.json`, etc.) are still required beside the EXE.
- Distribution should be a full `trading-server` folder, not EXE-only.

## 2. System Requirements

- Windows 10/11
- MetaTrader 5 terminal installed
- Node.js LTS (recommended: 18+)
- Internet connection (for npm and Cloudflare)
- Cloudflare account (if using public dashboard/deploy)

## 3. Folder Layout

Main folder used in this guide:

- `MQL5/Experts/trading-server`

Important files:

- `start-dashboard.ps1` - launcher GUI
- `server.js` - API server
- `.env` - runtime environment config
- `.env.example` - config template
- `public/dashboard.html` - main dashboard UI

## 4. First-Time Setup

### 4.1 Install dependencies

Open PowerShell in `trading-server`, then run:

```powershell
npm install
```

### 4.2 Create environment file

If `.env` does not exist, copy from template:

```powershell
Copy-Item .env.example .env
```

Set at least:

- `API_KEY`
- `CORS_ORIGIN`
- `CLOUDFLARE_PAGES_PROJECT` (if deploying)
- `CLOUDFLARE_PAGES_BRANCH` (default `production`)

### 4.3 MT5 WebRequest whitelist

In MT5:

1. Tools -> Options -> Expert Advisors
2. Enable "Allow WebRequest for listed URL"
3. Add both:
   - `http://127.0.0.1:3000`
   - `http://localhost:3000`

Notes:

- Do not use `https://127.0.0.1:3000` unless your local server is actually HTTPS.
- Using localhost/127 keeps EA stable even if trycloudflare URL changes.

## 5. Run with Launcher (Recommended)

Launch:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-dashboard.ps1
```

Typical flow:

1. Click Start Server
2. (Optional) Click Start Tunnel
3. Click Open Dashboard

## 6. Cloudflare Account Setup (For Your Customers Too)

Use button: **Cloudflare Setup** in launcher.

The wizard will:

- Check wrangler auth (`npx wrangler whoami`)
- Prompt login if needed (`npx wrangler login`)
- Ask Pages project and branch
- Save values to `.env`
- Optionally normalize dashboard URL
- Run test deploy
- Offer Node restart

This makes the package account-adaptive (not locked to one Cloudflare account/domain).

## 7. Daily Operation

### 7.1 Trading side

- Attach EA to chart
- Confirm `InpApiEnable = true`
- Ensure EA `InpApiKey` matches server `API_KEY`

### 7.2 Dashboard side

- Select account tab
- Monitor badges (`EA ONLINE`, `LIVE`)
- Use sections:
  - Open Positions
  - Pending Orders
  - Recent Reports
  - EA Settings

### 7.3 Presets

Preset scopes:

- Account Preset: stored per account
- Global Preset: one preset set for all accounts

Behavior:

- Last selected preset is remembered
- Last global preset can auto-apply on startup

## 8. Auto Deploy Behavior

Server supports auto deploy on public file changes.

Config in `.env`:

- `AUTO_DEPLOY_ON_PUBLIC_CHANGE=true`

When enabled:

- Changes in `public/*` trigger automatic Cloudflare Pages deploy.

Check status:

- `GET /api/deploy-status`

Example:

```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:3000/api/deploy-status" | ConvertTo-Json -Depth 6
```

## 9. Build and Distribution Notes (Sellable Package)

### 9.1 EX5 compile

Compile EA in MetaEditor on target machine:

- Open `.mq5`
- Build to `.ex5`

If CLI compile is desired, ensure MetaEditor is installed and available in PATH.

### 9.2 Security before shipping

Must-do before distributing:

1. Replace default API key with strong random key.
2. Ensure `.env` does not contain your private tokens.
3. Avoid bundling personal Cloudflare credentials.
4. Use launcher wizard so customer binds to their own Cloudflare account.

### 9.3 Recommended client package

Ship:

- EA `.mq5` and/or `.ex5`
- `trading-server` folder
- `.env.example` (template)
- This guide

Do not ship:

- Your personal `.env` with sensitive data
- Any private tokens

## 10. Troubleshooting

### 10.1 Error 4014 in MT5

Cause: URL not whitelisted in MT5 WebRequest list.

Fix:

- Add `http://127.0.0.1:3000`
- Add `http://localhost:3000`

### 10.2 Dashboard shows partial data

Checklist:

- API server running
- Correct API key
- Correct account selected
- Hard refresh browser (Ctrl+F5)

### 10.3 Deploy not updating

Check:

1. `npx wrangler whoami`
2. `CLOUDFLARE_PAGES_PROJECT` and `CLOUDFLARE_PAGES_BRANCH`
3. `/api/deploy-status`

### 10.4 Preset not applied

- Ensure proper scope selected (Account vs Global)
- Click Load Preset after selecting name
- For global, verify all accounts are visible/connected

## 11. Quick Start Checklist

- [ ] Node.js installed
- [ ] `npm install` done
- [ ] `.env` created and API key set
- [ ] MT5 WebRequest entries added
- [ ] EA attached and API key matched
- [ ] Launcher: Start Server
- [ ] Dashboard opens and account appears
- [ ] (Optional) Cloudflare Setup wizard completed
- [ ] (Optional) Auto deploy enabled

---

If you distribute this package, ask each customer to run Cloudflare Setup once on their own machine/account. That keeps deployment independent, adaptive, and portable.
