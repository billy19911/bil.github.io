param(
    [string]$PagesRepoPath = "..\..\..\bil.github.io",
    [switch]$NoPush
)

$ErrorActionPreference = "Stop"

$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$updateDir = Join-Path $sourceDir "update-feed"
$manifestSrc = Join-Path $updateDir "manifest.json"
$releasesSrc = Join-Path $updateDir "releases"

if (-not (Test-Path $manifestSrc)) {
    throw "manifest.json tidak ditemukan. Jalankan build-update-feed.ps1 dulu."
}

if (-not (Test-Path $PagesRepoPath)) {
    Write-Host "Clone bil.github.io repo?"
    $doClone = Read-Host "Path tidak ditemukan. Clone dari GitHub? (y/n)"
    if ($doClone -eq "y") {
        $parentDir = Split-Path -Parent $PagesRepoPath
        New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
        $cmd = "git clone https://github.com/billy19911/bil.github.io.git $PagesRepoPath"
        Write-Host "Jalankan: $cmd"
        Invoke-Expression $cmd
    } else {
        throw "Repo path tidak valid: $PagesRepoPath"
    }
}

Push-Location $PagesRepoPath

try {
    Write-Host "Sync bil.github.io repo..."
    git pull --quiet
    
    Write-Host "Copy manifest.json..."
    Copy-Item -Path $manifestSrc -Destination "manifest.json" -Force
    
    if (Test-Path $releasesSrc) {
        Write-Host "Copy releases..."
        $releasesDir = Join-Path $PagesRepoPath "releases"
        New-Item -ItemType Directory -Path $releasesDir -Force | Out-Null
        Copy-Item -Path "$releasesSrc\*" -Destination $releasesDir -Force -Include "*.zip"
    }
    
    $status = git status --short
    if (-not $status) {
        Write-Host "Tidak ada perubahan"
        return
    }
    
    Write-Host "Stagging..."
    git add manifest.json releases/ 2>$null
    
    Write-Host "Commit..."
    git commit -m "Auto-sync from trading-server update feed"
    
    if (-not $NoPush) {
        Write-Host "Push..."
        git push
        Write-Host "OK: Manifest dan releases sudah published ke bil.github.io"
        Write-Host "Tunggu ~2 menit untuk GitHub Pages update"
    } else {
        Write-Host "OK: Uncommitted changes siap. Use 'git push' untuk publish"
    }
    
} finally {
    Pop-Location
}
