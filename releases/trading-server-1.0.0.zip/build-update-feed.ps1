param(
    [string]$Version,
    [string]$Notes = "Maintenance update",
    [switch]$Force
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$packageJson = Join-Path $root "package.json"
if (-not $Version) {
    if (Test-Path $packageJson) {
        $pkg = Get-Content -Path $packageJson -Raw | ConvertFrom-Json
        $Version = [string]$pkg.version
    }
}

if (-not $Version) {
    throw "Version kosong. Pakai -Version 1.0.1"
}

$feedDir = Join-Path $root "update-feed"
$releasesDir = Join-Path $feedDir "releases"
New-Item -ItemType Directory -Path $releasesDir -Force | Out-Null

$tempDir = Join-Path $env:TEMP ("xau-release-" + [guid]::NewGuid().ToString("N"))
$stageDir = Join-Path $tempDir "trading-server"
$zipName = "trading-server-$Version.zip"
$zipPath = Join-Path $releasesDir $zipName

New-Item -ItemType Directory -Path $stageDir -Force | Out-Null

# Copy runtime files only; do not leak secrets/local state.
$null = robocopy $root $stageDir /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XD node_modules .git update-feed /XF .env launcher-config.json latest-dashboard-link.txt *.log
$copyCode = $LASTEXITCODE
if ($copyCode -ge 8) {
    throw "Robocopy gagal (exit code $copyCode)"
}

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}
Compress-Archive -Path (Join-Path $stageDir "*") -DestinationPath $zipPath -Force

$manifestPath = Join-Path $feedDir "manifest.json"
$manifest = [ordered]@{
    version = $Version
    zip_url = "https://billy19911.github.io/releases/$zipName"
    notes = $Notes
    force = [bool]$Force
    generated_at = (Get-Date).ToString("s")
}
$manifest | ConvertTo-Json | Set-Content -Path $manifestPath -Encoding ASCII

Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "OK: release siap"
Write-Host "ZIP      : $zipPath"
Write-Host "Manifest : $manifestPath"
Write-Host "Upload ke repo bil.github.io:"
Write-Host "- manifest.json ke root"
Write-Host "- $zipName ke folder releases/"
