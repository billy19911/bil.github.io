'use strict';

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const store = require('../store/data');

const OFFLINE_AFTER_MS = 15000;

router.get('/', auth, (req, res) => {
  const now = Date.now();
  const rows = Object.entries(store.accounts || {}).map(([account_id, acc]) => {
    const hb = acc?.status?.last_heartbeat || null;
    const ea_connected = hb ? (now - new Date(hb).getTime() <= OFFLINE_AFTER_MS) : false;
    const symbol = acc?.status?.account?.symbol || '-';
    const positions = Array.isArray(acc?.positions) ? acc.positions.length : 0;
    const pending = Array.isArray(acc?.pending_orders) ? acc.pending_orders.length : 0;
    return { account_id, ea_connected, last_heartbeat: hb, symbol, positions, pending };
  });

  rows.sort((a, b) => {
    if (a.ea_connected !== b.ea_connected) return a.ea_connected ? -1 : 1;
    return a.account_id.localeCompare(b.account_id);
  });

  return res.json({ accounts: rows });
});

module.exports = router;
