#Requires -Version 5.1
<#
.SYNOPSIS
    Deploy dashboard.html ke Cloudflare Pages dengan domain kamu sendiri.

.DESCRIPTION
    PRASYARAT:
    1. Node.js sudah terinstall
    2. Sudah punya akun Cloudflare dan domain sudah di Cloudflare
    3. Named Tunnel sudah setup (jalankan setup-named-tunnel.ps1 dulu)
    
    Script ini menggunakan Wrangler CLI (Cloudflare official tool).

.PARAMETER ProjectName
    Nama project di Cloudflare Pages (contoh: mt5-dashboard)

.PARAMETER BackendUrl
    URL backend kamu (tunnel domain), contoh: https://api.namadomain.com
    Akan diset sebagai default server di dashboard.

.EXAMPLE
    .\deploy-pages.ps1 -ProjectName "mt5-dashboard" -BackendUrl "https://api.namadomain.com"
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectName,
    
    [Parameter(Mandatory=$true)]
    [string]$BackendUrl,
    
    [string]$PublicDir = "$PSScriptRoot\..\public"
)

$ErrorActionPreference = 'Stop'

Write-Host "`n  ┌─────────────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "  │     Deploy ke Cloudflare Pages                  │" -ForegroundColor Cyan
Write-Host "  │     Project : $($ProjectName.PadRight(33))│" -ForegroundColor Cyan
Write-Host "  │     Backend : $($BackendUrl.PadRight(33))│" -ForegroundColor Cyan
Write-Host "  └─────────────────────────────────────────────────┘`n" -ForegroundColor Cyan

# ── Cek public dir ────────────────────────────────────────────────────────────
if (-not (Test-Path "$PublicDir\dashboard.html")) {
    Write-Host "[!] dashboard.html tidak ditemukan di: $PublicDir" -ForegroundColor Red
    exit 1
}

# ── Buat direktori temp deploy ────────────────────────────────────────────────
$deployDir = "$env:TEMP\mt5-pages-deploy"
if (Test-Path $deployDir) { Remove-Item $deployDir -Recurse -Force }
New-Item -ItemType Directory -Path $deployDir | Out-Null

# Copy semua file public ke deploy dir
Copy-Item "$PublicDir\*" $deployDir -Recurse
Write-Host "[1/3] File dashboard disalin ke: $deployDir" -ForegroundColor Green

# ── Cek wrangler ──────────────────────────────────────────────────────────────
Write-Host "`n[2/3] Cek wrangler CLI..." -ForegroundColor Yellow
$wrangler = $null
try {
    $wrangler = Get-Command "wrangler" -ErrorAction SilentlyContinue
} catch {}

if (-not $wrangler) {
    Write-Host "      Wrangler belum terinstall. Install sekarang via npx (tidak perlu install permanen)." -ForegroundColor Gray
    # Gunakan npx langsung, tidak perlu install global
    $useNpx = $true
    Write-Host "      ✓ Akan gunakan: npx wrangler" -ForegroundColor Green
} else {
    $useNpx = $false
    Write-Host "      ✓ Wrangler ditemukan" -ForegroundColor Green
}

# ── Deploy ────────────────────────────────────────────────────────────────────
Write-Host "`n[3/3] Deploy ke Cloudflare Pages..." -ForegroundColor Yellow
Write-Host "      Browser akan terbuka untuk login/authorize ke Cloudflare." -ForegroundColor Gray
Write-Host ""

Push-Location $deployDir
try {
    if ($useNpx) {
        npx wrangler pages deploy . --project-name $ProjectName --commit-dirty true
    } else {
        wrangler pages deploy . --project-name $ProjectName --commit-dirty true
    }
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "`n[!] Deploy gagal. Cek output di atas." -ForegroundColor Red
        Pop-Location
        exit 1
    }
} finally {
    Pop-Location
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host "`n  ╔══════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║            DEPLOY BERHASIL!                             ║" -ForegroundColor Green
Write-Host "  ╠══════════════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "  ║                                                          ║" -ForegroundColor Green
Write-Host "  ║  URL dashboard kamu (Cloudflare Pages):                  ║" -ForegroundColor Green
Write-Host "  ║  https://$("$ProjectName.pages.dev".PadRight(50))║" -ForegroundColor White
Write-Host "  ║  https://$("$ProjectName.pages.dev/dashboard.html".PadRight(50))║" -ForegroundColor White
Write-Host "  ║                                                          ║" -ForegroundColor Green
Write-Host "  ╠══════════════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "  ║  Langkah buka dashboard:                                 ║" -ForegroundColor Yellow
Write-Host "  ║  1. Buka URL di atas di browser/HP                      ║" -ForegroundColor Yellow
Write-Host "  ║  2. Klik ⚙️ (Settings) di pojok kiri                   ║" -ForegroundColor Yellow
Write-Host "  ║  3. Server URL: $($BackendUrl.PadRight(41))║" -ForegroundColor White
Write-Host "  ║  4. API Key: (sesuai .env kamu)                         ║" -ForegroundColor Yellow
Write-Host "  ║                                                          ║" -ForegroundColor Green
Write-Host "  ║  Atau langsung pakai link ini (auto-config):             ║" -ForegroundColor Yellow
Write-Host "  ║  https://$ProjectName.pages.dev/dashboard.html          ║" -ForegroundColor White
Write-Host "  ║  ?server=$(([uri]::EscapeDataString($BackendUrl)).PadRight(48))║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

# Tampilkan direct link
$encodedUrl = [uri]::EscapeDataString($BackendUrl)
$directLink = "https://$ProjectName.pages.dev/dashboard.html?server=$encodedUrl"
Write-Host "  Direct link (salin ke browser):" -ForegroundColor Cyan
Write-Host "  $directLink" -ForegroundColor White
Write-Host ""

# Simpan direct link ke file
$directLink | Set-Content "$PSScriptRoot\cloudflare-pages-url.txt" -Encoding UTF8
Write-Host "  Link disimpan ke: $PSScriptRoot\cloudflare-pages-url.txt" -ForegroundColor Gray

pause
