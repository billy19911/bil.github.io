#Requires -Version 5.1
<#
.SYNOPSIS
    Jalankan Cloudflare Quick Tunnel dan tampilkan URL untuk diakses dari HP.
.PARAMETER LocalPort
    Port server Node.js (default 3000)
#>
param([int]$LocalPort = 3000)

$cloudflaredExe = "$env:LOCALAPPDATA\cloudflared\cloudflared.exe"

# ── Cek cloudflared ───────────────────────────────────────────────────────────
if(-not (Test-Path $cloudflaredExe)) {
    Write-Host "[!] cloudflared.exe belum ada. Jalankan setup-cloudflare.ps1 dulu." -ForegroundColor Red
    pause; exit 1
}

Write-Host "`n  Memulai Cloudflare Quick Tunnel..." -ForegroundColor Cyan
Write-Host "  Menunggu URL... (biasanya 5-10 detik)`n" -ForegroundColor Gray

# ── Jalankan cloudflared, tangkap output secara real-time ─────────────────────
$psi                        = [System.Diagnostics.ProcessStartInfo]::new()
$psi.FileName               = $cloudflaredExe
$psi.Arguments              = "tunnel --url http://localhost:$LocalPort"
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError  = $true
$psi.UseShellExecute        = $false
$psi.CreateNoWindow         = $true

$proc = [System.Diagnostics.Process]::new()
$proc.StartInfo = $psi

$urlFound = $false
$tunnelUrl = ""

# Handler untuk stderr (cloudflared log URL ke stderr)
$errHandler = {
    $line = $Event.SourceEventArgs.Data
    if([string]::IsNullOrEmpty($line)) { return }

    if($line -match 'https://[a-z0-9\-]+\.trycloudflare\.com') {
        $script:tunnelUrl = $Matches[0]
        $script:urlFound  = $true

        # Simpan ke file
        $script:tunnelUrl | Set-Content "$env:LOCALAPPDATA\cloudflared\current-url.txt" -Encoding UTF8

        Write-Host ""
        Write-Host "  ╔══════════════════════════════════════════════════╗" -ForegroundColor Green
        Write-Host "  ║            URL PUBLIK KAMU (Quick Tunnel)        ║" -ForegroundColor Green
        Write-Host "  ╠══════════════════════════════════════════════════╣" -ForegroundColor Green
        Write-Host "  ║                                                  ║" -ForegroundColor Green
        Write-Host "  ║  $($script:tunnelUrl.PadRight(48))  ║" -ForegroundColor White
        Write-Host "  ║                                                  ║" -ForegroundColor Green
        Write-Host "  ║  Dashboard:                                      ║" -ForegroundColor Green
        Write-Host "  ║  $("$($script:tunnelUrl)/dashboard.html".PadRight(48))  ║" -ForegroundColor White
        Write-Host "  ║                                                  ║" -ForegroundColor Green
        Write-Host "  ╚══════════════════════════════════════════════════╝" -ForegroundColor Green
        Write-Host ""
        Write-Host "  Salin URL di atas ke browser HP kamu." -ForegroundColor Yellow
        Write-Host "  URL tersimpan di: $env:LOCALAPPDATA\cloudflared\current-url.txt" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  [Tekan Ctrl+C untuk menghentikan tunnel]`n" -ForegroundColor DarkGray
    }
}

Register-ObjectEvent -InputObject $proc -EventName "ErrorDataReceived"  -Action $errHandler | Out-Null

$proc.Start() | Out-Null
$proc.BeginErrorReadLine()
$proc.BeginOutputReadLine()

# Tunggu sampai URL muncul (max 30 detik)
$waited = 0
while(-not $urlFound -and $waited -lt 30) {
    Start-Sleep -Milliseconds 500
    $waited++
    Write-Host "  ." -NoNewline -ForegroundColor DarkGray
}

if(-not $urlFound) {
    Write-Host "`n[!] URL tidak terdeteksi dalam 30 detik." -ForegroundColor Red
    Write-Host "    Pastikan Node.js server sudah jalan di port $LocalPort" -ForegroundColor Yellow
}

# Biarkan tunnel jalan sampai Ctrl+C
try { $proc.WaitForExit() }
finally {
    try { $proc.Kill() } catch {}
    Write-Host "`nTunnel dihentikan." -ForegroundColor Gray
}
