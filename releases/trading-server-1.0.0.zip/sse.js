'use strict';

/**
 * SSE broadcaster — push real-time events ke semua dashboard yang terbuka.
 * 
 * Cara pakai:
 *   const sse = require('./sse');
 *   sse.push('status',  data);   // kirim event "status" ke semua client
 *   sse.push('report',  data);
 *   sse.push('signal',  data);
 *   sse.push('toggle',  data);
 *   sse.push('settings',data);
 */

const clients = new Set();

/** Daftarkan response object sebagai SSE client */
function connect(req, res) {
  res.setHeader('Content-Type',  'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection',    'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Nginx / Cloudflare jangan buffer
  res.flushHeaders();

  // Kirim ACK supaya browser tahu koneksi berhasil
  res.write('event: connected\ndata: {}\n\n');

  clients.add(res);

  // Hapus client saat koneksi putus
  req.on('close', () => clients.delete(res));
}

/** Kirim event ke semua dashboard yang sedang terbuka */
function push(event, data) {
  if (clients.size === 0) return;
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) {
    try { res.write(payload); }
    catch (_) { clients.delete(res); }
  }
}

/** Jumlah client aktif (untuk debugging) */
function count() { return clients.size; }

module.exports = { connect, push, count };
