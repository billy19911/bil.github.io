#Requires -Version 5.1
<#
.SYNOPSIS
    Setup Cloudflare Tunnel untuk MT5 Trading Server di Windows.
.DESCRIPTION
    Script ini:
      1. Download cloudflared.exe
      2. Jalankan quick tunnel (URL otomatis, tanpa login)
      3. (Opsional) Daftarkan sebagai Windows Task Scheduler agar auto-start saat login
.PARAMETER LocalPort
    Port server Node.js (default: 3000)
.EXAMPLE
    .\setup-cloudflare.ps1
    .\setup-cloudflare.ps1 -LocalPort 8080
#>
[CmdletBinding()]
param(
    [int]$LocalPort = 3000
)

$ErrorActionPreference = 'Stop'

$cloudflaredDir  = "$env:LOCALAPPDATA\cloudflared"
$cloudflaredExe  = "$cloudflaredDir\cloudflared.exe"
$downloadUrl     = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe'
$taskName        = 'CloudflaredMT5'
$logFile         = "$cloudflaredDir\tunnel.log"

Write-Host "`n==========================================" -ForegroundColor Cyan
Write-Host "  MT5 Trading Bot — Cloudflare Tunnel Setup" -ForegroundColor Cyan
Write-Host "==========================================`n" -ForegroundColor Cyan

# ── Step 1: Download cloudflared ──────────────────────────────────────────────
Write-Host "[1/3] Cek / Download cloudflared..." -ForegroundColor Yellow

if (-not (Test-Path $cloudflaredExe)) {
    New-Item -ItemType Directory -Force -Path $cloudflaredDir | Out-Null
    Write-Host "      Mengunduh dari GitHub..." -ForegroundColor Gray
    Invoke-WebRequest -Uri $downloadUrl -OutFile $cloudflaredExe -UseBasicParsing
    Write-Host "      Tersimpan di: $cloudflaredExe" -ForegroundColor Green
} else {
    Write-Host "      cloudflared sudah ada: $cloudflaredExe" -ForegroundColor Green
}

# Tampilkan versi
$ver = & $cloudflaredExe --version 2>&1
Write-Host "      Versi: $ver" -ForegroundColor Gray

# ── Step 2: Test quick tunnel ─────────────────────────────────────────────────
Write-Host "`n[2/3] Quick Tunnel (URL acak, tidak perlu akun Cloudflare)" -ForegroundColor Yellow
Write-Host "      Jalankan perintah ini di terminal terpisah:" -ForegroundColor Gray
Write-Host ""
Write-Host "      $cloudflaredExe tunnel --url http://localhost:$LocalPort" -ForegroundColor White
Write-Host ""
Write-Host "      URL publik Anda akan muncul di output, contoh:" -ForegroundColor Gray
Write-Host "      https://abc123.trycloudflare.com" -ForegroundColor Cyan
Write-Host ""
Write-Host "      Salin URL tersebut ke InpApiBaseUrl EA (tanpa /api di akhir)" -ForegroundColor Yellow

# ── Step 3: Task Scheduler (auto-start) ───────────────────────────────────────
Write-Host "`n[3/3] Auto-start via Windows Task Scheduler" -ForegroundColor Yellow
$choice = Read-Host "      Daftarkan sebagai task yang berjalan saat login? (y/N)"

if ($choice -in 'y','Y') {
    # Hapus task lama jika ada
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

    $action   = New-ScheduledTaskAction `
                    -Execute    $cloudflaredExe `
                    -Argument   "tunnel --url http://localhost:$LocalPort" `
                    -WorkingDirectory $cloudflaredDir

    $trigger  = New-ScheduledTaskTrigger -AtLogOn

    $settings = New-ScheduledTaskSettingsSet `
                    -ExecutionTimeLimit        ([TimeSpan]::Zero) `
                    -RestartCount              3 `
                    -RestartInterval           (New-TimeSpan -Minutes 1) `
                    -StartWhenAvailable        $true `
                    -RunOnlyIfNetworkAvailable $true

    Register-ScheduledTask `
        -TaskName  $taskName `
        -Action    $action `
        -Trigger   $trigger `
        -Settings  $settings `
        -RunLevel  Limited `
        -Force | Out-Null

    # Jalankan sekarang
    Start-ScheduledTask -TaskName $taskName
    Start-Sleep -Seconds 2

    $state = (Get-ScheduledTask -TaskName $taskName).State
    Write-Host ""
    Write-Host "      Task '$taskName' terdaftar. Status: $state" -ForegroundColor Green
    Write-Host "      Log tersimpan di: $logFile" -ForegroundColor Gray
    Write-Host ""
    Write-Host "      Untuk melihat URL tunnel, buka Task Scheduler dan" -ForegroundColor Yellow
    Write-Host "      cek History task, atau jalankan manual dulu untuk dapat URL-nya." -ForegroundColor Yellow

    Write-Host "`n      Perintah berguna:" -ForegroundColor Gray
    Write-Host "      Start : Start-ScheduledTask  -TaskName $taskName"
    Write-Host "      Stop  : Stop-ScheduledTask   -TaskName $taskName"
    Write-Host "      Hapus : Unregister-ScheduledTask -TaskName $taskName -Confirm:`$false"
} else {
    Write-Host "      Dilewati. Jalankan tunnel manual dengan perintah di Step 2." -ForegroundColor Gray
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host "`n===========================================" -ForegroundColor Cyan
Write-Host "  Setup selesai! Checklist:" -ForegroundColor Cyan
Write-Host "===========================================" -ForegroundColor Cyan
Write-Host "  [ ] Node.js server jalan: cd trading-server && npm start" -ForegroundColor White
Write-Host "  [ ] Cloudflare tunnel aktif (URL publik tercatat)" -ForegroundColor White
Write-Host "  [ ] MT5: Tools -> Options -> Expert Advisors" -ForegroundColor White
Write-Host "       Centang 'Allow WebRequest for listed URL'" -ForegroundColor White
Write-Host "       Tambahkan: http://localhost:3000" -ForegroundColor Yellow
Write-Host "  [ ] EA dipasang di chart, InpApiKey diisi" -ForegroundColor White
Write-Host "  [ ] Dashboard: http://localhost:3000/dashboard.html`n" -ForegroundColor Cyan
