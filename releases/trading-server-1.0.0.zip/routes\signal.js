'use strict';

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const store = require('../store/data');
const sse = require('../sse');

router.post('/', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  const signal = {
    ...req.body,
    created_at: new Date().toISOString(),
    account_id: accountId
  };

  accData.latestSignal = signal;
  accData.signals.unshift(signal);
  if (accData.signals.length > 100) accData.signals.length = 100;

  sse.push('signal', signal);
  return res.json({ success: true, signal });
});

router.get('/latest', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);
  return res.json({ signal: accData.latestSignal, account_id: accountId });
});

router.post('/clear', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  accData.latestSignal = null;
  return res.json({ success: true });
});

router.get('/', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);
  const limit = Math.min(parseInt(req.query.limit, 10) || 50, 100);
  return res.json({ signals: accData.signals.slice(0, limit), account_id: accountId });
});

module.exports = router;
