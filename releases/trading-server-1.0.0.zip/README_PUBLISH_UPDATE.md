# Auto-Update Release Process

## Alur Otomatis

Sekarang kamu bisa totally otomatis:

### 1. Kamu Edit Version di `package.json`

Contoh:
```json
{
  "version": "1.0.1",
  ...
}
```

### 2. Commit & Push ke Repo

```powershell
git add package.json
git commit -m "Release v1.0.1"
git push
```

### 3. GitHub Actions Otomatis Run

Workflow [.github/workflows/auto-update-feed.yml](.github/workflows/auto-update-feed.yml) akan:
- Auto-build manifest.json dan zip release
- Auto-commit artifacts ke update-feed/ folder
- Auto-push ke repo

### 4. Sync ke bil.github.io (Pilihan A: Script Lokal)

Setelah workflow selesai, jalankan script sync lokal:

```powershell
.\sync-to-pages.ps1
```

Script ini akan:
- Clone/pull repo bil.github.io
- Copy manifest.json ke root
- Copy releases/*.zip ke folder releases/
- Commit dan push

### 5. Atau (Pilihan B: Manual Copy)

Cukup copy:
- `update-feed/manifest.json` → root bil.github.io repo
- `update-feed/releases/*.zip` → releases/ folder

Tunggu ~2 menit GitHub Pages publish.

## Manual Trigger

Bisa juga trigger workflow manual di GitHub dengan custom release notes:

1. Buka repo trading-server di GitHub
2. Actions -> Auto Build Update Feed -> Run workflow
3. Isi Release Notes dan Force flag
4. Klik Run

## Buyer Flow

1. Buyer set `UPDATE_MANIFEST_URL=https://billy19911.github.io/manifest.json`
2. Setiap kali launcher buka, cek update otomatis
3. Ada update → auto download dan apply
4. Atau buyer klik "Check Update" manual

## Test Cepat

Di launcher buyer, klik "Env Settings" dan:
- Isi UPDATE_MANIFEST_URL = https://billy19911.github.io/manifest.json
- Isi AUTO_UPDATE_ENABLED = true
- Klik Check Update

Harusnya langsung detect versi baru.
