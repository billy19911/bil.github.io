'use strict';

const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const store   = require('../store/data');
const sse     = require('../sse');

// ── POST /api/report ──────────────────────────────────────────────────────────
// EA submits a trade execution report after acting on a signal.
//
// Body JSON (example):
//   { "action":"BUY", "symbol":"XAUUSD", "lot":0.01,
//     "success":true, "balance":10050.00, "equity":10055.00, "time":"2026.04.01 10:00:05" }
router.post('/', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  const report = {
    ...req.body,
    received_at: new Date().toISOString(),
    account_id: accountId
  };

  // Strong dedupe by MT5 deal ticket (when provided)
  if (report.deal_ticket != null) {
    const key = String(report.deal_ticket);
    const exists = accData.reports.some(r => String(r.deal_ticket || '') === key);
    if (exists) return res.json({ success: true, deduped: true, by: 'deal_ticket' });
  }

  // Dedupe report jika payload identik dengan report terbaru
  const last = accData.reports[0];
  if (last &&
      String(last.time || '') === String(report.time || '') &&
      String(last.action || '') === String(report.action || '') &&
      String(last.symbol || '') === String(report.symbol || '') &&
      Number(last.lot || 0) === Number(report.lot || 0) &&
      Number(last.price || 0) === Number(report.price || 0)) {
    return res.json({ success: true, deduped: true });
  }

  accData.reports.unshift(report);
  if (accData.reports.length > 500) accData.reports.length = 500;

  sse.push('report', report);

  return res.json({ success: true });
});

// ── GET /api/report ───────────────────────────────────────────────────────────
// Fetch recent trade reports for the specified account. Optional query param: ?limit=50
router.get('/', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);
  const limit = Math.min(parseInt(req.query.limit, 10) || 50, 500);
  return res.json({ reports: accData.reports.slice(0, limit), account_id: accountId });
});

// ── POST /api/report/reset ───────────────────────────────────────────────────
// Manual reset WR/report history for one account.
router.post('/reset', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  accData.reports = [];

   // Also notify EA to reset chart-side WR baseline.
   const signal = {
     action: 'RESET_WR',
     created_at: new Date().toISOString(),
     account_id: accountId
   };
   accData.latestSignal = signal;
   accData.signals.unshift(signal);
   if (accData.signals.length > 100) accData.signals.length = 100;
   sse.push('signal', signal);

  sse.push('report_reset', {
    account_id: accountId,
    reset_at: new Date().toISOString()
  });

  return res.json({ success: true, account_id: accountId });
});

module.exports = router;
