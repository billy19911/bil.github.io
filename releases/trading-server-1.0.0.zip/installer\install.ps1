#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function New-Shortcut([string]$targetPath, [string]$shortcutPath, [string]$workingDirectory) {
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $targetPath
        $shortcut.WorkingDirectory = $workingDirectory
        $shortcut.Save()
    } catch {
        # ignore shortcut creation failure
    }
}

try {
    $sourceDir = $PSScriptRoot
    $payloadZip = Join-Path $sourceDir 'payload.zip'
    if (-not (Test-Path $payloadZip)) {
        throw 'payload.zip tidak ditemukan di paket installer.'
    }

    $installDir = Join-Path $env:LOCALAPPDATA 'XAU-Monster-Dashboard'
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null

    $tempExtract = Join-Path $env:TEMP ('xau-install-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempExtract -Force | Out-Null

    Expand-Archive -Path $payloadZip -DestinationPath $tempExtract -Force

    $appRoot = $tempExtract
    if (-not (Test-Path (Join-Path $appRoot 'server.js'))) {
        $candidate = Get-ChildItem -Path $tempExtract -Directory -Recurse |
            Where-Object { Test-Path (Join-Path $_.FullName 'server.js') } |
            Select-Object -First 1
        if ($candidate) {
            $appRoot = $candidate.FullName
        } else {
            throw 'Isi paket tidak valid (server.js tidak ditemukan).'
        }
    }

    $null = robocopy $appRoot $installDir /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XF .env launcher-config.json latest-dashboard-link.txt npm-install.log /XD node_modules .git
    if ($LASTEXITCODE -ge 8) {
        throw ('Gagal copy file installer (robocopy code {0})' -f $LASTEXITCODE)
    }

    $desktop = [Environment]::GetFolderPath('Desktop')
    $shortcutPath = Join-Path $desktop 'XAU Dashboard Launcher.lnk'
    $launcherExe = Join-Path $installDir 'XAU-Dashboard-Launcher.exe'
    $launcherPs1 = Join-Path $installDir 'start-dashboard.ps1'

    if (Test-Path $launcherExe) {
        New-Shortcut -targetPath $launcherExe -shortcutPath $shortcutPath -workingDirectory $installDir
    } elseif (Test-Path $launcherPs1) {
        $psTarget = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        New-Shortcut -targetPath $psTarget -shortcutPath $shortcutPath -workingDirectory $installDir
    }

    Remove-Item -Path $tempExtract -Recurse -Force -ErrorAction SilentlyContinue

    $msg = "Install selesai.`r`n`r`nLokasi: $installDir`r`nShortcut desktop dibuat.`r`n`r`nBuka launcher sekarang?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'XAU Dashboard Setup', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Information)
    if ($res -eq [System.Windows.Forms.DialogResult]::Yes) {
        if (Test-Path $launcherExe) {
            Start-Process $launcherExe | Out-Null
        } elseif (Test-Path $launcherPs1) {
            Start-Process powershell.exe -ArgumentList '-ExecutionPolicy', 'Bypass', '-File', $launcherPs1 -WorkingDirectory $installDir | Out-Null
        }
    }
} catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'XAU Dashboard Setup Error', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    exit 1
}
