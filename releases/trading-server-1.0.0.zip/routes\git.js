'use strict';

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { execSync } = require('child_process');
const path = require('path');

function deployToCloudflarePages(projectRoot) {
  const projectName = process.env.CLOUDFLARE_PAGES_PROJECT || 'mt5-dashboard';
  const branchName = process.env.CLOUDFLARE_PAGES_BRANCH || 'production';
  const cmd = `npx wrangler pages deploy public --project-name ${projectName} --branch ${branchName} --commit-dirty=true`;
  const output = execSync(cmd, {
    cwd: projectRoot,
    encoding: 'utf-8',
    stdio: 'pipe',
    timeout: 120000
  });
  return {
    status: `deployed to Cloudflare Pages (${projectName}/${branchName})`,
    output
  };
}

// Git commit endpoint - auto-commit current state and deploy to Cloudflare
router.post('/commit', auth, (req, res) => {
  try {
    const { message = 'Auto-commit from dashboard', deploy = true } = req.body;
    const projectRoot = path.join(__dirname, '..');
    
    // Check if git is initialized
    try {
      execSync('git rev-parse --git-dir', { 
        cwd: projectRoot,
        stdio: 'pipe'
      });
    } catch (_) {
      // Git tidak wajib; deploy Cloudflare tetap bisa jalan.
      if (deploy) {
        try {
          const dep = deployToCloudflarePages(projectRoot);
          return res.json({ ok: true, skipped: true, reason: 'git not initialized', cloudflare_deploy: dep.status });
        } catch (e) {
          return res.json({ ok: false, error: `deploy failed: ${e.message}` });
        }
      }
      return res.json({ ok: true, skipped: true, reason: 'git not initialized' });
    }

    // Stage all changes (including dashboard.html)
    try {
      execSync('git add -A', { cwd: projectRoot, stdio: 'pipe' });
    } catch (e) {
      console.error('Git add failed:', e.message);
    }

    // Check if there are changes to commit
    let status;
    try {
      status = execSync('git status --porcelain', { 
        cwd: projectRoot,
        encoding: 'utf-8',
        stdio: 'pipe'
      });
    } catch (_) {
      status = '';
    }

    let committed = false;
    let commitMsg = null;

    if (status.trim()) {
      // Commit with timestamp only when there are tracked changes.
      const timestamp = new Date().toISOString();
      commitMsg = `${message} (${timestamp})`;

      try {
        execSync(`git commit -m "${commitMsg.replace(/"/g, '\\"')}"`, {
          cwd: projectRoot,
          encoding: 'utf-8',
          stdio: 'pipe'
        });
        committed = true;
        console.log(`✓ Commit: ${commitMsg}`);
      } catch (e) {
        return res.json({
          ok: false,
          error: `Commit failed: ${e.message}`
        });
      }
    }

    // Optional push disabled by default to avoid browser auth popup to Forge remote.
    let pushStatus = null;
    if (String(process.env.ENABLE_GIT_PUSH || '').toLowerCase() === 'true') {
      try {
        let currentBranch;
        try {
          currentBranch = execSync('git rev-parse --abbrev-ref HEAD', {
            cwd: projectRoot,
            encoding: 'utf-8',
            stdio: 'pipe'
          }).trim();
        } catch (_) {
          currentBranch = 'production';
        }

        execSync(`git push origin ${currentBranch}`, {
          cwd: projectRoot,
          encoding: 'utf-8',
          stdio: 'pipe',
          timeout: 30000
        });
        pushStatus = `pushed to origin/${currentBranch}`;
      } catch (e) {
        pushStatus = `push failed: ${e.message}`;
      }
    } else {
      pushStatus = 'push skipped (ENABLE_GIT_PUSH != true)';
    }

    // Try to deploy to Cloudflare Pages using wrangler
    let deployStatus = null;
    let deployOutput = null;
    try {
      if (deploy) {
        const dep = deployToCloudflarePages(projectRoot);
        deployStatus = dep.status;
        deployOutput = dep.output;
      } else {
        deployStatus = 'deploy skipped (deploy=false)';
      }
      console.log(`✓ ${deployStatus}`);
    } catch (e) {
      console.error('Wrangler deploy failed:', e.message);
      deployStatus = `deploy failed: ${e.message}`;
    }

    res.json({ 
      ok: true, 
      message: commitMsg,
      committed,
      git_push: pushStatus,
      cloudflare_deploy: deployStatus,
      deploy_log: deployOutput
    });

  } catch (e) {
    console.error('Commit error:', e.message);
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
