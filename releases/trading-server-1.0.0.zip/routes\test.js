'use strict';

const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const store   = require('../store/data');

// ── POST /api/test/populate-reports ──────────────────────────────────────────
// Helper endpoint to generate test reports data for demo/testing
router.post('/populate-reports', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);

  // Clear existing reports
  accData.reports = [];

  // Create sample reports
  // Helper: format date as MT5 "YYYY.MM.DD HH:MM:SS"
  const mt5time = (ms) => {
    const d = new Date(ms);
    const p = n => String(n).padStart(2,'0');
    return `${d.getFullYear()}.${p(d.getMonth()+1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  };

  const sampleReports = [
    // Trade 1: BUY + immediate close (2 detik later)
    {
      time: mt5time(Date.now() - 30000),
      symbol: 'XAUUSD',
      action: 'BUY',
      lot: 0.01,
      price: 4765.33,
      profit: 0.00,
      sl: 4759.33,
      tp: 4780.33,
      success: true,
      balance: 10050,
      equity: 10050,
      received_at: new Date(Date.now() - 30000).toISOString(),
      account_id: accountId
    },
    {
      time: mt5time(Date.now() - 27000),
      symbol: 'XAUUSD',
      action: 'BUY_CLOSE',
      lot: 0.01,
      price: 4767.33,
      profit: 2.00,
      success: true,
      balance: 10052,
      equity: 10052,
      note: 'closed',
      received_at: new Date(Date.now() - 27000).toISOString(),
      account_id: accountId
    },
    // Trade 2: SELL + close (3 detik later)
    {
      time: mt5time(Date.now() - 24000),
      symbol: 'XAUUSD',
      action: 'SELL',
      lot: 0.01,
      price: 4767.09,
      profit: 0.00,
      sl: 4773.09,
      tp: 4755.09,
      success: true,
      balance: 10052,
      equity: 10052,
      received_at: new Date(Date.now() - 24000).toISOString(),
      account_id: accountId
    },
    {
      time: mt5time(Date.now() - 21000),
      symbol: 'XAUUSD',
      action: 'SELL_CLOSE',
      lot: 0.01,
      price: 4765.07,
      profit: -6.02,
      success: true,
      balance: 10045.98,
      equity: 10045.98,
      note: 'closed',
      received_at: new Date(Date.now() - 21000).toISOString(),
      account_id: accountId
    },
    // Trade 3: BUY
    {
      time: mt5time(Date.now() - 18000),
      symbol: 'XAUUSD',
      action: 'BUY',
      lot: 0.02,
      price: 4761.04,
      profit: 0.00,
      sl: 4755.04,
      tp: 4776.04,
      success: true,
      balance: 10045.98,
      equity: 10045.98,
      received_at: new Date(Date.now() - 18000).toISOString(),
      account_id: accountId
    },
    {
      time: mt5time(Date.now() - 15000),
      symbol: 'XAUUSD',
      action: 'BUY_CLOSE',
      lot: 0.02,
      price: 4767.09,
      profit: 12.10,
      success: true,
      balance: 10058.08,
      equity: 10058.08,
      note: 'closed',
      received_at: new Date(Date.now() - 15000).toISOString(),
      account_id: accountId
    }
  ];

  accData.reports = sampleReports;

  console.log(`[TEST] Added ${sampleReports.length} sample reports to account ${accountId}`);
  return res.json({ success: true, reports: sampleReports, account_id: accountId });
});

// ── GET /api/test/status ──────────────────────────────────────────────────────────
// Helper endpoint to populate a sample status
router.post('/fake-status', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);

  // Simulate EA heartbeat
  accData.status.ea_connected = true;
  accData.status.last_heartbeat = new Date().toISOString();
  accData.status.account = {
    balance: 10150.00,
    equity: 10165.50,
    free_margin: 5082.50,
    open_positions: 2,
    symbol: 'XAUUSD',
    today_pnl: 150.00,
    drawdown_pct: 0.3,
    bull_votes: 2,
    bear_votes: 1,
    adx: 22.5
  };

  if (!accData.positions || accData.positions.length === 0) {
    accData.positions = [
      {
        ticket: 123001,
        open_time: new Date(Date.now() - 1800000).toISOString().split('T')[0] + ' ' + new Date(Date.now() - 1800000).toLocaleTimeString(),
        symbol: 'XAUUSD',
        type: 'BUY',
        volume: 0.01,
        open_price: 2350.50,
        current_price: 2355.20,
        sl: 2340.00,
        tp: 2370.00,
        swap: 0.50,
        profit: 47.00
      },
      {
        ticket: 123002,
        open_time: new Date(Date.now() - 900000).toISOString().split('T')[0] + ' ' + new Date(Date.now() - 900000).toLocaleTimeString(),
        symbol: 'XAUUSD',
        type: 'SELL',
        volume: 0.02,
        open_price: 2360.00,
        current_price: 2355.20,
        sl: 2370.00,
        tp: 2340.00,
        swap: -0.75,
        profit: 103.50
      }
    ];
  }

  console.log(`[TEST] Populated fake status for account ${accountId}`);
  return res.json({ success: true, account_id: accountId, trading_enabled: accData.status.trading_enabled });
});

// ── GET /api/test/clear-account ──────────────────────────────────────────────────
// Clear all data for an account
router.post('/clear-account', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  delete store.accounts[accountId];
  console.log(`[TEST] Cleared account ${accountId}`);
  return res.json({ success: true, message: `Account ${accountId} cleared` });
});

module.exports = router;
