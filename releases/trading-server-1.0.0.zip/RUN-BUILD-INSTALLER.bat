@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-single-installer.ps1"
if errorlevel 1 (
  echo.
  echo Build installer gagal.
  pause
  exit /b 1
)
echo.
echo Build installer selesai.
pause
