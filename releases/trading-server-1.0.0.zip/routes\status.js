'use strict';

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const store = require('../store/data');
const sse = require('../sse');

const OFFLINE_AFTER_MS = 15000;

router.post('/', auth, (req, res) => {
  // Extract account ID from query or body (default: 'default' for single account)
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);

  accData.status.ea_connected = true;
  accData.status.last_heartbeat = new Date().toISOString();

  // Extract arrays separately, rest goes into account
  const { positions, pending_orders_list, ...accountData } = req.body;
  accData.status.account = accountData;

  // Store positions
  if (Array.isArray(positions)) {
    accData.positions = positions;
  }
  if (Array.isArray(pending_orders_list)) {
    accData.pending_orders = pending_orders_list;
  }

  // IMPORTANT:
  // Do not override server toggle state from EA heartbeat payload.
  // `remote_paused` is treated as telemetry only; authoritative state is /api/toggle.

  sse.push('status', {
    ...accData.status,
    positions: accData.positions,
    pending_orders: accData.pending_orders,
    public_url: process.env.PUBLIC_BASE_URL || '',
    account_id: accountId
  });

  return res.json({ success: true, trading_enabled: accData.status.trading_enabled });
});

router.get('/', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);

  if (accData.status.last_heartbeat) {
    const elapsed = Date.now() - new Date(accData.status.last_heartbeat).getTime();
    accData.status.ea_connected = elapsed <= OFFLINE_AFTER_MS;
  } else {
    accData.status.ea_connected = false;
  }

  return res.json({
    ...accData.status,
    positions: accData.positions,
    pending_orders: accData.pending_orders,
    public_url: process.env.PUBLIC_BASE_URL || '',
    account_id: accountId
  });
});

module.exports = router;
