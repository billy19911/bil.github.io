'use strict';

const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const store   = require('../store/data');
const sse     = require('../sse');

// Field definitions: [key, type, min, max]
const FIELDS = [
  ['base_lot',            'float',  0.01,  100],
  ['max_spread',          'int',    0,     10000],
  ['max_drawdown_pct',    'float',  0,     100],
  ['daily_profit_target', 'float',  0,     1e6],
  ['use_martingale',      'int01',  0,     1],
  ['martingale_mult',     'float',  1.0,   20],
  ['max_mart_steps',      'int',    1,     20],
  ['max_layers',          'int',    1,     50],
  ['farming_gap',         'float',  0.01,  100],
  ['mart_start_layer',    'int',    1,     50],
  ['initial_sl',          'float',  0.01,  100],
  ['trail_start',         'float',  0.01,  100],
  ['trail_stop',          'float',  0.01,  100],
  ['trail_step',          'float',  0.001, 10],
  ['use_breakeven',       'int01',  0,     1],
  ['be_distance',         'float',  0.01,  100],
  ['be_buffer',           'float',  0.001, 10],
  ['use_pending_guard',   'int01',  0,     1],
  ['always_in_market',    'int01',  0,     1],
  ['instant_reentry',     'int01',  0,     1],
  ['auto_flip',           'int01',  0,     1],
  ['use_trend_filter',    'int01',  0,     1],
  ['use_ema_ribbon',      'int01',  0,     1],
  ['use_dmi',             'int01',  0,     1],
  ['use_mkt_struct',      'int01',  0,     1],
  ['use_early_trend',     'int01',  0,     1],
  ['adx_level',           'float',  1,     100],
  ['ema_fast',            'int',    1,     100],
  ['ema_slow',            'int',    1,     100],
  ['adx_bars',            'int',    1,     10],
  ['ema_slope_min',       'float',  0,     1],
  ['use_sniper_entry',    'int01',  0,     1],
  ['adx_sideways',        'float',  1,     100],
  ['confirmation_bars',   'int',    0,     10],
  ['bb_period',           'int',    5,     200],
  ['bb_deviation',        'float',  0.1,   10],
  ['rsi_period',          'int',    2,     100],
  ['rsi_buy_level',       'float',  1,     99],
  ['rsi_sell_level',      'float',  1,     99],
  ['adx_period',          'int',    2,     100],
  ['atr_period',          'int',    2,     100],
  ['ema_period',          'int',    2,     200],
  ['start_hour',          'int',    0,     23],
  ['end_hour',            'int',    0,     23],
];

// ── GET /api/settings ─────────────────────────────────────────────────────────
router.get('/', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);
  return res.json({ ...accData.settings, account_id: accountId });
});

// ── POST /api/settings ────────────────────────────────────────────────────────
router.post('/', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  const errors = [];

  for (const [key, type, min, max] of FIELDS) {
    if (req.body[key] == null) continue;
    let v;
    if (type === 'float') {
      v = parseFloat(req.body[key]);
      if (isNaN(v) || v < min || v > max) { errors.push(`${key} harus ${min}-${max}`); continue; }
    } else if (type === 'int' || type === 'int01') {
      v = parseInt(req.body[key], 10);
      if (isNaN(v) || v < min || v > max) { errors.push(`${key} harus ${min}-${max}`); continue; }
    }
    accData.settings[key] = v;
  }

  if (errors.length) return res.status(400).json({ errors });

  console.log(`[SETTINGS] Account ${accountId}:`, accData.settings);
  sse.push('settings', { ...accData.settings, account_id: accountId });
  return res.json({ success: true, settings: accData.settings, account_id: accountId });
});

module.exports = router;
