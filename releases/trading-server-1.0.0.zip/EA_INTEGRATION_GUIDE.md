# EA Integration Guide - Multi-Account Trading Dashboard

## Quick Start

### 1. Dashboard Access
- **URL**: `http://localhost:3000/dashboard.html`
- **API Server**: `http://localhost:3000`
- **API Key**: `mt5secret123456` (set in .env)

### 2. API Authentication
All requests require the X-API-Key header:
```
X-API-Key: mt5secret123456
Content-Type: application/json
```

### 3. Account Identification
Specify account via `account_id` parameter (query or body):
```javascript
GET /api/status?account_id=Terminal-A
POST /api/toggle { enabled: false, account_id: Terminal-A }
```

---

## Key Endpoints for EA

### Status Heartbeat
The EA should send periodic heartbeats to keep connection alive and receive trading state:

**Request:**
```javascript
POST /api/status
{
  "account_id": "EA-XAU-M1",           // Your terminal ID
  "remote_paused": false,              // True if EA should pause trading
  "account": {
    "balance": 10000.00,
    "equity": 9950.00,
    "free_margin": 4900.00,
    "open_positions": 2,
    "symbol": "XAUUSD",
    "today_pnl": -50.00,
    "drawdown_pct": 0.5,
    "bull_votes": 2,
    "bear_votes": 1,
    "adx": 25.3
  },
  "positions": [
    {
      "ticket": 123456,
      "open_time": "2026.04.01 10:30:00",
      "symbol": "XAUUSD",
      "type": "BUY",
      "volume": 0.01,
      "open_price": 2350.50,
      "current_price": 2355.20,
      "sl": 2340.00,
      "tp": 2370.00,
      "swap": 0.50,
      "profit": 47.00
    }
  ]
}
```

**Response:**
```javascript
{
  "success": true,
  "trading_enabled": true,    // Read this! If false, pause trading
  "account_id": "EA-XAU-M1"
}
```

### Receive Settings Updates
The EA should poll for updated settings (or use SSE):

**Request:**
```
GET /api/settings?account_id=EA-XAU-M1
```

**Response:**
```javascript
{
  "base_lot": 0.01,
  "max_drawdown_pct": 5.0,
  "daily_profit_target": 0.0,
  "use_martingale": 1,
  "martingale_mult": 2.0,
  "max_mart_steps": 2,
  "max_layers": 1,
  "farming_gap": 2.0,
  "mart_start_layer": 2,
  "initial_sl": 6.0,
  "trail_start": 5.0,
  "trail_stop": 1.3,
  "trail_step": 0.1,
  "use_breakeven": 0,
  "be_distance": 2.0,
  "be_buffer": 0.01,
  "use_pending_guard": 1,
  "always_in_market": 1,
  "instant_reentry": 1,
  "auto_flip": 0,
  "use_trend_filter": 1,
  "use_ema_ribbon": 1,
  "use_dmi": 1,
  "use_mkt_struct": 1,
  "use_early_trend": 1,
  "adx_level": 18.0,
  "ema_fast": 8,
  "ema_slow": 21,
  "adx_bars": 2,
  "ema_slope_min": 0.02,
  "start_hour": 0,
  "end_hour": 23,
  "account_id": "EA-XAU-M1"
}
```

### Report Trade Execution
After executing a trade signal:

**Request:**
```javascript
POST /api/report
{
  "account_id": "EA-XAU-M1",
  "action": "BUY",
  "symbol": "XAUUSD",
  "lot": 0.01,
  "success": true,
  "balance": 9950.00,
  "equity": 9940.00,
  "time": "2026.04.01 10:30:00"
}
```

**Response:**
```javascript
{ "success": true }
```

---

## Dashboard UI Integration

### Trading State Management

**Flow:**
1. EA sends heartbeat with `remote_paused` field
2. Dashboard displays toggle button:
   - GREEN "Disable Trading" (when enabled)
   - RED "Enable Trading" (when disabled)
3. User clicks button → sends POST /api/toggle
4. Server updates state per-account
5. EA's next heartbeat receives `trading_enabled` in response
6. EA checks: `if (remote_paused != !trading_enabled)` then update

**Key Points:**
- `trading_enabled` = inverse of `remote_paused`
- Each account has separate trading state
- Toggle only affects that specific account's EA
- Real-time update via SSE to dashboard

### Multi-Account Example

**Terminal A (EA-BTC-M1):**
```
POST /api/status { account_id: "EA-BTC-M1", remote_paused: false }
→ stored in store.getAccount("EA-BTC-M1")
→ toggle state isolated
```

**Terminal B (EA-XAU-M1):**
```
POST /api/status { account_id: "EA-XAU-M1", remote_paused: false }
→ stored in store.getAccount("EA-XAU-M1")
→ toggle state isolated
```

**Dashboard Switch Between Accounts:**
```
currentAccountId changes based on latest heartbeat
Settings sync with currentAccountId
Reports/Signals filtered by currentAccountId
Toggle only affects currentAccountId account
```

---

## Error Handling

### Common Errors

**401 Unauthorized**
```
Missing or invalid X-API-Key header
→ Fix: Include header with correct key
```

**400 Bad Request**
```
{ error: '"enabled" must be a boolean (true or false)' }
→ Fix: Ensure enabled is true or false, not 1/0
```

**Settings Validation**
```
{ errors: ["base_lot harus 0.01-100"] }
→ Fix: Check min/max values in FIELDS array
```

---

## Polling vs SSE

### Option 1: Polling (Simple)
```javascript
// EA polls every 2 seconds
setInterval(() => {
  GET /api/settings?account_id=EA_ID
}, 2000);
```

### Option 2: SSE (Real-time)
```javascript
// Connect once, receive updates
GET /api/stream
→ Listens for events:
  - "status" events
  - "settings" events
  - "toggle" events
  - "report" events
```

---

## Testing Checklist

- [ ] EA sends heartbeat to POST /api/status
- [ ] Dashboard receives and displays account balance/equity
- [ ] Toggle button changes state per-account
- [ ] Next heartbeat response includes correct trading_enabled
- [ ] Multiple EAs (different account_ids) don't interfere
- [ ] Settings changes persist and sync to dashboard
- [ ] Reports appear in Recent Reports table
- [ ] Time display shows correctly (HH:MM:SS)
- [ ] Mobile UI responsive (if applicable)

---

## Performance Notes

- **Heartbeat Interval**: Recommend 2-5 seconds
- **Settings Sync**: ~2 seconds polling or SSE real-time
- **Report Logging**: Kept in memory (500/account max)
- **Signal Logging**: Kept in memory (100/account max)
- **No DB Required**: Works with in-memory store

---

## Troubleshooting

**Issue**: Dashboard shows "EA OFFLINE"
- Solution: EA not sending heartbeats or offline after 15 seconds

**Issue**: Settings not updating in EA
- Solution: Check if EA reads response from GET /api/settings or SSE stream

**Issue**: Toggle doesn't work
- Solution: Verify account_id matches, check X-API-Key header

**Issue**: Positions show wrong values
- Solution: Ensure POST /api/status includes "positions" array

---

## Security Notes

⚠️ **API Key**: Change mt5secret123456 in .env for production
⚠️ **CORS**: Configure based on your deployment
⚠️ **Firewall**: Restrict /api endpoints to trusted IPs
⚠️ **WebRequest**: Only enable when necessary

---

## Support

- Server: `http://localhost:3000`
- Health Check: `GET /health`
- Dashboard: `http://localhost:3000/dashboard.html`
- Log Files: Check console output
