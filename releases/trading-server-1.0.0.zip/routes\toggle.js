'use strict';

const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const store   = require('../store/data');
const sse     = require('../sse');

// ── POST /api/toggle ──────────────────────────────────────────────────────────
// Enable or disable trading from the dashboard.
//
// Body: { "enabled": true }  or  { "enabled": false }
router.post('/', auth, (req, res) => {
  const accountId = req.query.account_id || req.body.account_id || 'default';
  const accData = store.getAccount(accountId);
  const { enabled } = req.body;

  if (typeof enabled !== 'boolean') {
    return res.status(400).json({ error: '"enabled" must be a boolean (true or false)' });
  }

  accData.status.trading_enabled = enabled;
  console.log(`[TOGGLE] Account ${accountId}: Trading ${enabled ? 'ENABLED' : 'DISABLED'}`);

  sse.push('toggle', { trading_enabled: enabled, account_id: accountId });

  return res.json({ success: true, trading_enabled: accData.status.trading_enabled, account_id: accountId });
});

// ── GET /api/toggle ───────────────────────────────────────────────────────────
// Read current toggle state.
router.get('/', auth, (req, res) => {
  const accountId = req.query.account_id || 'default';
  const accData = store.getAccount(accountId);
  return res.json({ trading_enabled: accData.status.trading_enabled, account_id: accountId });
});

module.exports = router;
