'use strict';

/**
 * Multi-account data store.
 * Each account (MT5 terminal) maintains separate positions/settings.
 */
const store = {
  // account_id (terminal ID) -> account state
  accounts: {},
  
  // Get or create account state
  getAccount(accountId = 'default') {
    if (!this.accounts[accountId]) {
      this.accounts[accountId] = {
        status: {
          ea_connected: false,
          trading_enabled: true,
          last_heartbeat: null,
          account: {}
        },
        positions: [],
        pending_orders: [],
        signals: [],
        latestSignal: null,
        reports: [],
        settings: {
          // Risk & Lot (EA inputs defaults)
          base_lot: 0.01,
          max_spread: 999,
          max_drawdown_pct: 5.0,
          daily_profit_target: 0.0,
          // Recovery & Grid
          use_martingale: 1,
          martingale_mult: 2.0,
          max_mart_steps: 2,
          max_layers: 1,
          farming_gap: 2.0,
          mart_start_layer: 2,
          // Trailing & Exits
          initial_sl: 6.0,
          trail_start: 5.0,
          trail_stop: 1.3,
          trail_step: 0.1,
          use_breakeven: 0,
          be_distance: 2.0,
          be_buffer: 0.01,
          // Guards
          use_pending_guard: 1,
          // Beast Mode
          always_in_market: 1,
          instant_reentry: 1,
          auto_flip: 0,
          // AI Engine toggles
          use_trend_filter: 1,
          use_ema_ribbon: 1,
          use_dmi: 1,
          use_mkt_struct: 1,
          use_early_trend: 1,
          adx_level: 18.0,
          ema_fast: 8,
          ema_slow: 21,
          adx_bars: 2,
          ema_slope_min: 0.02,
          use_sniper_entry: 1,
          adx_sideways: 20.0,
          confirmation_bars: 2,
          // Indicator base (runtime re-init capable)
          bb_period: 14,
          bb_deviation: 1.5,
          rsi_period: 7,
          rsi_buy_level: 30.0,
          rsi_sell_level: 70.0,
          adx_period: 14,
          atr_period: 5,
          ema_period: 21,
          // Schedule
          start_hour: 0,
          end_hour: 23
        }
      };
    }
    return this.accounts[accountId];
  }
};

module.exports = store;
