# Quick Start Pembeli - XAU Monster Dashboard

Dokumen ini versi paling simpel dan langsung praktik.

## 1) Paket Yang Dikirim ke Pembeli

Wajib kirim 1 folder trading-server lengkap, minimal berisi:

- start-dashboard.exe ATAU start-dashboard.ps1
- server.js
- package.json
- folder public
- .env.example

Catatan penting:

- EXE launcher hanya pembungkus UI launcher.
- EXE tidak otomatis berisi semua file runtime Node/dashboard.
- Jadi tidak bisa kirim EXE saja.

## 2) Install Sekali

1. Install Node.js LTS (18+).
2. Buka folder trading-server.
3. Jalankan npm install.
4. Copy .env.example menjadi .env.

## 3) Langkah Cloudflare Token + Deploy

Cara bikin token Cloudflare:

1. Login ke Cloudflare Dashboard.
2. Buka My Profile -> API Tokens.
3. Klik Create Token.
4. Pilih template Edit Cloudflare Workers (boleh custom token kalau paham).
5. Simpan token.

Isi token dan setting deploy:

1. Buka launcher.
2. Klik Env Settings.
3. Isi:
   - CLOUDFLARE_API_TOKEN
   - CLOUDFLARE_PAGES_PROJECT
   - CLOUDFLARE_PAGES_BRANCH
   - CORS_ORIGIN
4. Klik Save.
5. Klik Cloudflare Setup untuk test deploy.

## 4) Jalankan Harian

1. Buka launcher.
2. Klik Start Server.
3. Opsional klik Start Tunnel.
4. Klik Open Dashboard.

## 5) Setting MT5 (Wajib)

Di MT5 -> Tools -> Options -> Expert Advisors -> Allow WebRequest, tambah:

- http://127.0.0.1:3000
- http://localhost:3000

Di EA:

- API enable harus aktif
- API key EA harus sama dengan API_KEY di .env

## 6) Auto Update Buyer Dari API Kamu

Launcher sekarang mendukung auto update dari API manifest kamu.

Yang perlu diisi di Env Settings atau .env:

- UPDATE_MANIFEST_URL
- AUTO_UPDATE_ENABLED=true

Format JSON manifest (host di server kamu sendiri):

```json
{
  "version": "1.0.1",
  "zip_url": "https://your-domain.com/releases/trading-server-1.0.1.zip",
  "notes": "Fix signal filter and stability"
}
```

Cara kerja:

- Saat launcher dibuka, jika AUTO_UPDATE_ENABLED=true maka launcher cek update otomatis.
- Kalau ada versi baru, buyer ditanya lalu bisa update otomatis.
- Tombol Check Update juga tersedia untuk cek manual kapan saja.
- File .env dan launcher-config.json buyer tidak ditimpa saat update.

## 7) Catatan Untuk Penjual

Sebelum kirim ke buyer:

- jangan kirim .env pribadi
- jangan kirim token Cloudflare pribadi
- kirim .env.example sebagai template
- buyer isi token/domain milik mereka sendiri
