#Requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

function Resolve-LauncherBaseDir() {
    if ($PSScriptRoot -and (Test-Path $PSScriptRoot)) {
        return $PSScriptRoot
    }

    if ($MyInvocation -and $MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        $p = Split-Path $MyInvocation.MyCommand.Path -Parent
        if ($p -and (Test-Path $p)) { return $p }
    }

    # Fallback untuk runtime EXE/host non-standar.
    if ([System.AppDomain]::CurrentDomain.BaseDirectory) {
        $p = [System.AppDomain]::CurrentDomain.BaseDirectory.TrimEnd('\\','/')
        if ($p -and (Test-Path $p)) { return $p }
    }

    return (Get-Location).Path
}

$ServerDir      = Resolve-LauncherBaseDir
$CloudflaredExe = "$env:LOCALAPPDATA\cloudflared\cloudflared.exe"
$LogFile        = "$env:LOCALAPPDATA\cloudflared\tunnel.log"
$DefaultDashboardUrl = "https://your-dashboard.pages.dev/dashboard.html"
$ShareFile      = Join-Path $ServerDir "latest-dashboard-link.txt"
$ConfigFile     = Join-Path $ServerDir "launcher-config.json"
$EnvFile        = Join-Path $ServerDir ".env"
$EnvExampleFile = Join-Path $ServerDir ".env.example"
$GuideBuyerFile = Join-Path $ServerDir "README_BUYER.md"
$GuideFile      = if (Test-Path $GuideBuyerFile) { $GuideBuyerFile } else { Join-Path $ServerDir "README_INSTALLATION.md" }
$AssetsDir      = Join-Path $ServerDir "assets"
$LauncherIco    = Join-Path $AssetsDir "launcher.ico"
$GuideIco       = Join-Path $AssetsDir "guide.ico"
$CommonFilesDir = Join-Path $env:APPDATA "MetaQuotes\Terminal\Common\Files\EAMonster"
$CommonApiFile  = Join-Path $CommonFilesDir "cloud_api_base.txt"

$script:NodeProc      = $null
$script:TunnelProc    = $null
$script:TunnelUrl     = ""
$script:LastTunnelUrl = ""
$script:DepsReady     = $false
$script:DashboardUrl  = $DefaultDashboardUrl
$script:ServerOverride = ""
$script:AutoUpdateChecked = $false

# Form
$form = New-Object System.Windows.Forms.Form
$form.Text            = "XAU Monster - Dashboard Launcher"
$form.Size            = New-Object System.Drawing.Size(500, 540)
$form.StartPosition   = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox     = $false
$form.BackColor       = [System.Drawing.Color]::FromArgb(24, 24, 32)
$form.ForeColor       = [System.Drawing.Color]::White
$form.Font            = New-Object System.Drawing.Font("Segoe UI", 9)

try {
    if (Test-Path $LauncherIco) {
        $form.Icon = New-Object System.Drawing.Icon($LauncherIco)
    } else {
        $form.Icon = [System.Drawing.SystemIcons]::Application
    }
} catch {
    $form.Icon = [System.Drawing.SystemIcons]::Application
}

function MakeLabel($text, $x, $y, $w=200, $h=20) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x,$y)
    $l.Size = New-Object System.Drawing.Size($w,$h)
    $l.ForeColor = [System.Drawing.Color]::Silver
    $form.Controls.Add($l); return $l
}
function MakeBtn($text, $x, $y, $w=140, $h=36, $color="333355") {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object System.Drawing.Point($x,$y)
    $b.Size = New-Object System.Drawing.Size($w,$h)
    $b.BackColor = [System.Drawing.Color]::FromArgb(0x33,0x33,0x66)
    $b.ForeColor = [System.Drawing.Color]::White
    $b.FlatStyle = "Flat"
    $b.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(80,80,120)
    $form.Controls.Add($b); return $b
}
function SetButtonIcon($btn, $iconObj) {
    if (-not $btn -or -not $iconObj) { return }
    try {
        $btn.Image = $iconObj.ToBitmap()
        $btn.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $btn.TextImageRelation = [System.Windows.Forms.TextImageRelation]::ImageBeforeText
        $btn.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    } catch {
        # ignore icon issues to keep launcher functional
    }
}
function MakeDot($x,$y) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Size = New-Object System.Drawing.Size(14,14)
    $p.Location = New-Object System.Drawing.Point($x,$y)
    $p.BackColor = [System.Drawing.Color]::Gray
    $form.Controls.Add($p); return $p
}

# Title
$title = New-Object System.Windows.Forms.Label
$title.Text = "XAU Monster Dashboard"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(255,200,50)
$title.Location = New-Object System.Drawing.Point(20,15)
$title.Size = New-Object System.Drawing.Size(440,30)
$form.Controls.Add($title)

# Server section
MakeLabel "Node.js Server (port 3000)" 20 60 250 | Out-Null
$dotNode = MakeDot 270 63
$btnStartNode  = MakeBtn "Start Server"  20  85 140
$btnStopNode   = MakeBtn "Stop Server"   170 85 140
$lblNodeStatus = MakeLabel "Status: Stopped" 20 128 440
$lblNodeStatus.ForeColor = [System.Drawing.Color]::OrangeRed

# Tunnel section
MakeLabel "Cloudflare Tunnel" 20 160 250 | Out-Null
$dotTunnel = MakeDot 200 163
$btnStartTunnel = MakeBtn "Start Tunnel"  20  185 140
$btnStopTunnel  = MakeBtn "Stop Tunnel"   170 185 140
$lblTunnelUrl   = MakeLabel "URL: (belum aktif)" 20 228 440
$lblTunnelUrl.ForeColor = [System.Drawing.Color]::FromArgb(100,180,255)

# Open Dashboard
$sep = New-Object System.Windows.Forms.Panel
$sep.Location = New-Object System.Drawing.Point(20,265)
$sep.Size = New-Object System.Drawing.Size(430,1)
$sep.BackColor = [System.Drawing.Color]::FromArgb(60,60,80)
$form.Controls.Add($sep)

$btnOpen = MakeBtn "Open Dashboard in Browser" 20 278 280 38
$btnOpen.BackColor = [System.Drawing.Color]::FromArgb(30,90,50)
$btnOpen.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(60,160,80)
$btnOpen.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)

$btnCopy = MakeBtn "Copy URL" 310 278 130 38
$btnCopy.BackColor = [System.Drawing.Color]::FromArgb(50,50,70)

$lblShareUrl = MakeLabel "Share: https://your-dashboard.pages.dev/dashboard.html" 20 320 430 22
$lblShareUrl.ForeColor = [System.Drawing.Color]::FromArgb(120, 200, 255)

# Settings rows
MakeLabel "Dashboard URL:" 20 348 110 20 | Out-Null
$txtDashboard = New-Object System.Windows.Forms.TextBox
$txtDashboard.Location = New-Object System.Drawing.Point(130, 345)
$txtDashboard.Size = New-Object System.Drawing.Size(320, 22)
$txtDashboard.Text = $script:DashboardUrl
$form.Controls.Add($txtDashboard)

MakeLabel "Server Override:" 20 376 110 20 | Out-Null
$txtServerOverride = New-Object System.Windows.Forms.TextBox
$txtServerOverride.Location = New-Object System.Drawing.Point(130, 373)
$txtServerOverride.Size = New-Object System.Drawing.Size(320, 22)
$txtServerOverride.Text = $script:ServerOverride
$form.Controls.Add($txtServerOverride)

$btnSaveSettings = MakeBtn "Save Domain Settings" 20 402 170 30
$btnSaveSettings.BackColor = [System.Drawing.Color]::FromArgb(40, 90, 130)
$btnSaveSettings.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(80, 150, 200)

$btnClearOverride = MakeBtn "Clear Override" 200 402 120 30
$btnClearOverride.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 80)

$btnCloudflareSetup = MakeBtn "Cloudflare Setup" 330 402 120 30
$btnCloudflareSetup.BackColor = [System.Drawing.Color]::FromArgb(80, 60, 30)
$btnCloudflareSetup.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(170, 130, 70)

$btnEnvSettings = MakeBtn "Env Settings" 20 438 140 30
$btnEnvSettings.BackColor = [System.Drawing.Color]::FromArgb(40, 70, 100)
$btnEnvSettings.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(90, 140, 190)

$btnCheckUpdate = MakeBtn "Check Update" 170 438 130 30
$btnCheckUpdate.BackColor = [System.Drawing.Color]::FromArgb(55, 85, 35)
$btnCheckUpdate.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(110, 170, 75)

SetButtonIcon $btnStartNode [System.Drawing.SystemIcons]::Information
SetButtonIcon $btnStopNode [System.Drawing.SystemIcons]::Error
SetButtonIcon $btnStartTunnel [System.Drawing.SystemIcons]::Shield
SetButtonIcon $btnStopTunnel [System.Drawing.SystemIcons]::Warning
SetButtonIcon $btnOpen [System.Drawing.SystemIcons]::Asterisk
SetButtonIcon $btnCopy [System.Drawing.SystemIcons]::Question
SetButtonIcon $btnSaveSettings [System.Drawing.SystemIcons]::Application
SetButtonIcon $btnCloudflareSetup [System.Drawing.SystemIcons]::Shield
SetButtonIcon $btnEnvSettings [System.Drawing.SystemIcons]::WinLogo
SetButtonIcon $btnCheckUpdate [System.Drawing.SystemIcons]::Information

$lnkGuide = New-Object System.Windows.Forms.LinkLabel
$lnkGuide.Text = "View Installation Guide"
$lnkGuide.Location = New-Object System.Drawing.Point(330, 444)
$lnkGuide.Size = New-Object System.Drawing.Size(140, 18)
$lnkGuide.LinkColor = [System.Drawing.Color]::FromArgb(120, 200, 255)
$lnkGuide.ActiveLinkColor = [System.Drawing.Color]::FromArgb(180, 230, 255)
$lnkGuide.VisitedLinkColor = [System.Drawing.Color]::FromArgb(120, 200, 255)
$form.Controls.Add($lnkGuide)

$picGuide = New-Object System.Windows.Forms.PictureBox
$picGuide.Location = New-Object System.Drawing.Point(310, 443)
$picGuide.Size = New-Object System.Drawing.Size(16,16)
$picGuide.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
try {
    if (Test-Path $GuideIco) {
        $picGuide.Image = (New-Object System.Drawing.Icon($GuideIco)).ToBitmap()
    } else {
        $picGuide.Image = [System.Drawing.SystemIcons]::Information.ToBitmap()
    }
} catch {
    $picGuide.Image = [System.Drawing.SystemIcons]::Information.ToBitmap()
}
$form.Controls.Add($picGuide)

# Log
$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true; $log.ReadOnly = $true; $log.ScrollBars = "Vertical"
$log.Location = New-Object System.Drawing.Point(20,458)
$log.Size = New-Object System.Drawing.Size(430,30)
$log.BackColor = [System.Drawing.Color]::FromArgb(15,15,20)
$log.ForeColor = [System.Drawing.Color]::FromArgb(120,210,120)
$log.BorderStyle = "None"
$form.Controls.Add($log)

function Log($msg) {
    $log.Text = "[$(Get-Date -Format 'HH:mm:ss')] $msg"
}
function SetDot($dot, $on) {
    $dot.BackColor = if($on) { [System.Drawing.Color]::LimeGreen } else { [System.Drawing.Color]::Gray }
}

function TrySetClipboard($text, $maxRetry = 5, $sleepMs = 150) {
    for ($i = 1; $i -le $maxRetry; $i++) {
        try {
            [System.Windows.Forms.Clipboard]::SetText($text)
            return $true
        } catch {
            Start-Sleep -Milliseconds $sleepMs
        }
    }
    return $false
}

function PromptText([string]$prompt, [string]$title, [string]$default = "") {
    return [Microsoft.VisualBasic.Interaction]::InputBox($prompt, $title, $default)
}

function ShowGuidePanel() {
    $content = ""
    if (Test-Path $GuideFile) {
        try {
            $content = Get-Content -Path $GuideFile -Raw
        } catch {
            $content = "Gagal membaca file panduan.`r`n`r`n$GuideFile"
        }
    } else {
        $content = "File panduan belum ditemukan:`r`n`r`n$GuideFile"
    }

    $guideForm = New-Object System.Windows.Forms.Form
    $guideForm.Text = "Installation Guide"
    $guideForm.Size = New-Object System.Drawing.Size(860, 650)
    $guideForm.StartPosition = "CenterParent"
    $guideForm.FormBorderStyle = "Sizable"
    $guideForm.MinimizeBox = $true
    $guideForm.MaximizeBox = $true
    $guideForm.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 28)
    $guideForm.ForeColor = [System.Drawing.Color]::White
    $guideForm.Font = New-Object System.Drawing.Font("Segoe UI", 9)

    try {
        if ($form.Icon) { $guideForm.Icon = $form.Icon }
    } catch {}

    $guideBox = New-Object System.Windows.Forms.TextBox
    $guideBox.Multiline = $true
    $guideBox.ReadOnly = $true
    $guideBox.ScrollBars = "Both"
    $guideBox.WordWrap = $false
    $guideBox.Location = New-Object System.Drawing.Point(12, 12)
    $guideBox.Size = New-Object System.Drawing.Size(820, 555)
    $guideBox.Anchor = "Top,Bottom,Left,Right"
    $guideBox.BackColor = [System.Drawing.Color]::FromArgb(12, 12, 18)
    $guideBox.ForeColor = [System.Drawing.Color]::FromArgb(210, 225, 255)
    $guideBox.BorderStyle = "FixedSingle"
    $guideBox.Text = $content
    $guideForm.Controls.Add($guideBox)

    $btnCloseGuide = New-Object System.Windows.Forms.Button
    $btnCloseGuide.Text = "Close"
    $btnCloseGuide.Size = New-Object System.Drawing.Size(96, 32)
    $btnCloseGuide.Location = New-Object System.Drawing.Point(736, 576)
    $btnCloseGuide.Anchor = "Bottom,Right"
    $btnCloseGuide.FlatStyle = "Flat"
    $btnCloseGuide.BackColor = [System.Drawing.Color]::FromArgb(45, 65, 95)
    $btnCloseGuide.ForeColor = [System.Drawing.Color]::White
    $btnCloseGuide.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(90, 120, 170)
    $btnCloseGuide.Add_Click({ $guideForm.Close() })
    $guideForm.Controls.Add($btnCloseGuide)

    $guideForm.ShowDialog($form) | Out-Null
}

function ShowEnvSettingsPanel() {
    if (-not (EnsureEnvFile)) {
        [System.Windows.Forms.MessageBox]::Show(".env tidak ditemukan dan .env.example juga tidak ada.", "Env Settings") | Out-Null
        return
    }

    $envForm = New-Object System.Windows.Forms.Form
    $envForm.Text = "Env Settings"
    $envForm.Size = New-Object System.Drawing.Size(760, 560)
    $envForm.StartPosition = "CenterParent"
    $envForm.FormBorderStyle = "FixedDialog"
    $envForm.MaximizeBox = $false
    $envForm.MinimizeBox = $false
    $envForm.BackColor = [System.Drawing.Color]::FromArgb(24, 24, 32)
    $envForm.ForeColor = [System.Drawing.Color]::White
    $envForm.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    try {
        if ($form.Icon) { $envForm.Icon = $form.Icon }
    } catch {}

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Text = "Isi token/API key di sini lalu klik Save. Nilai akan disimpan ke file .env"
    $lblInfo.Location = New-Object System.Drawing.Point(20, 16)
    $lblInfo.Size = New-Object System.Drawing.Size(710, 24)
    $lblInfo.ForeColor = [System.Drawing.Color]::FromArgb(190, 210, 235)
    $envForm.Controls.Add($lblInfo)

    $labels = @(
        @{ Name = "API_KEY"; Y = 58; Default = ""; Secret = $true },
        @{ Name = "CLOUDFLARE_API_TOKEN"; Y = 108; Default = ""; Secret = $true },
        @{ Name = "CLOUDFLARE_PAGES_PROJECT"; Y = 158; Default = "your-dashboard"; Secret = $false },
        @{ Name = "CLOUDFLARE_PAGES_BRANCH"; Y = 208; Default = "production"; Secret = $false },
        @{ Name = "CORS_ORIGIN"; Y = 258; Default = "*"; Secret = $false },
        @{ Name = "UPDATE_MANIFEST_URL"; Y = 308; Default = ""; Secret = $false },
        @{ Name = "AUTO_UPDATE_ENABLED"; Y = 358; Default = "true"; Secret = $false }
    )

    $inputs = @{}
    foreach ($item in $labels) {
        $key = [string]$item.Name
        $y = [int]$item.Y

        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = $key
        $lbl.Location = New-Object System.Drawing.Point(20, $y)
        $lbl.Size = New-Object System.Drawing.Size(235, 24)
        $lbl.ForeColor = [System.Drawing.Color]::Silver
        $envForm.Controls.Add($lbl)

        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Location = New-Object System.Drawing.Point(260, ($y - 3))
        $tb.Size = New-Object System.Drawing.Size(470, 26)
        $tb.Text = GetEnvValue $key ([string]$item.Default)
        $tb.BackColor = [System.Drawing.Color]::FromArgb(16, 16, 24)
        $tb.ForeColor = [System.Drawing.Color]::White
        $tb.BorderStyle = "FixedSingle"
        if ([bool]$item.Secret) {
            $tb.UseSystemPasswordChar = $true
        }
        $envForm.Controls.Add($tb)
        $inputs[$key] = $tb
    }

    $chkShowSecrets = New-Object System.Windows.Forms.CheckBox
    $chkShowSecrets.Text = "Show API key/token"
    $chkShowSecrets.Location = New-Object System.Drawing.Point(260, 414)
    $chkShowSecrets.Size = New-Object System.Drawing.Size(230, 26)
    $chkShowSecrets.ForeColor = [System.Drawing.Color]::FromArgb(170, 205, 255)
    $chkShowSecrets.Add_CheckedChanged({
        $show = $chkShowSecrets.Checked
        if ($inputs.ContainsKey("API_KEY")) { $inputs["API_KEY"].UseSystemPasswordChar = -not $show }
        if ($inputs.ContainsKey("CLOUDFLARE_API_TOKEN")) { $inputs["CLOUDFLARE_API_TOKEN"].UseSystemPasswordChar = -not $show }
    })
    $envForm.Controls.Add($chkShowSecrets)

    $chkAutoDeploy = New-Object System.Windows.Forms.CheckBox
    $chkAutoDeploy.Text = "AUTO_DEPLOY_ON_PUBLIC_CHANGE"
    $chkAutoDeploy.Location = New-Object System.Drawing.Point(20, 414)
    $chkAutoDeploy.Size = New-Object System.Drawing.Size(240, 42)
    $chkAutoDeploy.ForeColor = [System.Drawing.Color]::FromArgb(170, 205, 255)
    $autoDeployRaw = (GetEnvValue "AUTO_DEPLOY_ON_PUBLIC_CHANGE" "true").ToLowerInvariant()
    $chkAutoDeploy.Checked = ($autoDeployRaw -eq "1" -or $autoDeployRaw -eq "true" -or $autoDeployRaw -eq "yes")
    $envForm.Controls.Add($chkAutoDeploy)

    $btnSaveEnv = New-Object System.Windows.Forms.Button
    $btnSaveEnv.Text = "Save"
    $btnSaveEnv.Size = New-Object System.Drawing.Size(120, 36)
    $btnSaveEnv.Location = New-Object System.Drawing.Point(490, 460)
    $btnSaveEnv.FlatStyle = "Flat"
    $btnSaveEnv.BackColor = [System.Drawing.Color]::FromArgb(36, 96, 62)
    $btnSaveEnv.ForeColor = [System.Drawing.Color]::White
    $btnSaveEnv.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(76, 156, 102)

    $btnCancelEnv = New-Object System.Windows.Forms.Button
    $btnCancelEnv.Text = "Cancel"
    $btnCancelEnv.Size = New-Object System.Drawing.Size(120, 36)
    $btnCancelEnv.Location = New-Object System.Drawing.Point(620, 460)
    $btnCancelEnv.FlatStyle = "Flat"
    $btnCancelEnv.BackColor = [System.Drawing.Color]::FromArgb(62, 62, 78)
    $btnCancelEnv.ForeColor = [System.Drawing.Color]::White
    $btnCancelEnv.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(100, 100, 120)
    $btnCancelEnv.Add_Click({ $envForm.Close() })

    $btnSaveEnv.Add_Click({
        $apiKey = $inputs["API_KEY"].Text.Trim()
        if (-not $apiKey) {
            [System.Windows.Forms.MessageBox]::Show("API_KEY tidak boleh kosong.", "Env Settings") | Out-Null
            return
        }

        foreach ($item in $labels) {
            $k = [string]$item.Name
            $v = $inputs[$k].Text.Trim()
            SetEnvValue $k $v
        }

        SetEnvValue "AUTO_DEPLOY_ON_PUBLIC_CHANGE" (if ($chkAutoDeploy.Checked) { "true" } else { "false" })
        Log "Env settings tersimpan (.env)"
        [System.Windows.Forms.MessageBox]::Show("Env settings tersimpan ke .env", "Env Settings") | Out-Null
        $envForm.Close()
    })

    $envForm.Controls.Add($btnSaveEnv)
    $envForm.Controls.Add($btnCancelEnv)
    $envForm.ShowDialog($form) | Out-Null
}

function EnsureEnvFile() {
    if (Test-Path $EnvFile) { return $true }
    if (Test-Path $EnvExampleFile) {
        Copy-Item $EnvExampleFile $EnvFile -Force
        return $true
    }
    return $false
}

function GetEnvValue([string]$key, [string]$default = "") {
    if (-not (Test-Path $EnvFile)) { return $default }
    $line = Get-Content -Path $EnvFile | Where-Object { $_ -match ('^' + [regex]::Escape($key) + '=') } | Select-Object -First 1
    if (-not $line) { return $default }
    return ($line -replace ('^' + [regex]::Escape($key) + '='), '').Trim()
}

function SetEnvValue([string]$key, [string]$value) {
    $safe = [string]$value
    $lines = @()
    if (Test-Path $EnvFile) {
        $lines = Get-Content -Path $EnvFile
    }
    $prefix = $key + '='
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match ('^' + [regex]::Escape($key) + '=')) {
            $lines[$i] = $prefix + $safe
            $found = $true
            break
        }
    }
    if (-not $found) {
        $lines += ($prefix + $safe)
    }
    Set-Content -Path $EnvFile -Value $lines -Encoding ASCII
}

function WaitJobWithDoEvents($job, [int]$pollMs = 150) {
    while ($job.State -eq 'Running') {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds $pollMs
    }
}

function TryWranglerWhoAmI() {
    try {
        $job = Start-Job -ScriptBlock { npx wrangler whoami 2>&1 }
        WaitJobWithDoEvents $job
        $out = Receive-Job $job -ErrorAction SilentlyContinue
        $txt = ($out -join "`n")
        $ok = ($job.State -eq 'Completed') -and ($txt -match 'Account Name|account_id|User Email')
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        return $ok
    } catch {
        return $false
    }
}

function ConvertToVersionObject([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return [version]"0.0.0" }
    $m = [regex]::Match($value, '\d+(\.\d+){0,3}')
    if (-not $m.Success) { return [version]"0.0.0" }

    $parts = $m.Value.Split('.')
    while ($parts.Count -lt 3) { $parts += '0' }
    if ($parts.Count -gt 4) { $parts = $parts[0..3] }

    try {
        return [version]($parts -join '.')
    } catch {
        return [version]"0.0.0"
    }
}

function GetLocalAppVersion() {
    $pkgFile = Join-Path $ServerDir "package.json"
    if (-not (Test-Path $pkgFile)) { return "0.0.0" }
    try {
        $pkg = Get-Content -Path $pkgFile -Raw | ConvertFrom-Json
        if ($pkg.version -and ($pkg.version -is [string])) {
            return $pkg.version
        }
    } catch {}
    return "0.0.0"
}

function ParseBool([string]$value, [bool]$default = $false) {
    if ([string]::IsNullOrWhiteSpace($value)) { return $default }
    $v = $value.Trim().ToLowerInvariant()
    return ($v -eq "1" -or $v -eq "true" -or $v -eq "yes" -or $v -eq "on")
}

function GetUpdateInfo() {
    if (-not (EnsureEnvFile)) { return $null }

    $manifestUrl = (GetEnvValue "UPDATE_MANIFEST_URL" "").Trim()
    if (-not $manifestUrl) { return $null }

    try {
        $manifest = Invoke-RestMethod -Uri $manifestUrl -Method Get -TimeoutSec 20 -ErrorAction Stop
    } catch {
        Log "Update check gagal: API manifest tidak bisa diakses"
        return $null
    }

    $remoteVersion = [string]$manifest.version
    $zipUrl = [string]$manifest.zip_url
    if ([string]::IsNullOrWhiteSpace($remoteVersion) -or [string]::IsNullOrWhiteSpace($zipUrl)) {
        Log "Manifest update tidak valid (wajib: version, zip_url)"
        return $null
    }

    $localVersion = GetLocalAppVersion
    $hasUpdate = (ConvertToVersionObject $remoteVersion) -gt (ConvertToVersionObject $localVersion)

    $forceUpdate = $false
    if ($manifest.PSObject.Properties['force']) {
        $forceUpdate = ParseBool ([string]$manifest.force) $false
    }

    return [pscustomobject]@{
        local_version = $localVersion
        remote_version = $remoteVersion
        zip_url = $zipUrl
        notes = [string]$manifest.notes
        has_update = $hasUpdate
        force = $forceUpdate
        manifest_url = $manifestUrl
    }
}

function ApplyUpdatePackage([string]$zipUrl, [string]$remoteVersion) {
    if ([string]::IsNullOrWhiteSpace($zipUrl)) { return $false }

    $tmpRoot = Join-Path $env:TEMP ("xau-monster-update-" + [guid]::NewGuid().ToString("N"))
    $zipPath = Join-Path $tmpRoot "update.zip"
    $extractPath = Join-Path $tmpRoot "extract"

    $nodeWasRunning = (Get-Process -Name node -ErrorAction SilentlyContinue) -ne $null
    $tunnelWasRunning = (Get-Process -Name cloudflared -ErrorAction SilentlyContinue) -ne $null

    try {
        New-Item -Path $tmpRoot -ItemType Directory -Force | Out-Null

        Log "Download update package..."
        Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 180

        Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

        $sourceRoot = $extractPath
        if (-not (Test-Path (Join-Path $sourceRoot "server.js"))) {
            $candidate = Get-ChildItem -Path $extractPath -Directory -Recurse |
                Where-Object { Test-Path (Join-Path $_.FullName "server.js") } |
                Select-Object -First 1
            if ($candidate) {
                $sourceRoot = $candidate.FullName
            } else {
                throw "Paket update tidak valid (server.js tidak ditemukan)."
            }
        }

        Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force
        Get-Process -Name cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force
        $script:NodeProc = $null
        $script:TunnelProc = $null
        $script:TunnelUrl = ""
        $script:LastTunnelUrl = ""

        $null = robocopy $sourceRoot $ServerDir /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XD node_modules .git /XF .env launcher-config.json latest-dashboard-link.txt
        $copyCode = $LASTEXITCODE
        if ($copyCode -ge 8) {
            throw ("Copy update gagal (robocopy exit code {0})" -f $copyCode)
        }

        if (Test-Path (Join-Path $ServerDir "package.json")) {
            Log "Install dependency setelah update..."
            $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "npm install --no-audit --no-fund" -WorkingDirectory $ServerDir -Wait -PassThru -WindowStyle Hidden
            if ($p.ExitCode -ne 0) {
                Log "npm install pasca-update gagal, jalankan manual jika perlu"
            }
        }

        if ($nodeWasRunning -and (EnsureServerReady)) {
            $script:NodeProc = Start-Process node -ArgumentList "server.js" -WorkingDirectory $ServerDir -PassThru -WindowStyle Hidden
        }
        if ($tunnelWasRunning -and (Test-Path $CloudflaredExe)) {
            Remove-Item $LogFile -ErrorAction SilentlyContinue
            $script:TunnelProc = Start-Process $CloudflaredExe -ArgumentList "tunnel --url http://localhost:3000 --logfile `"$LogFile`"" -PassThru -WindowStyle Hidden
        }

        Log ("Update sukses ke versi {0}" -f $remoteVersion)
        [System.Windows.Forms.MessageBox]::Show(("Update berhasil ke versi {0}." -f $remoteVersion), "Auto Update") | Out-Null
        return $true
    } catch {
        Log ("Update gagal: {0}" -f $_.Exception.Message)
        [System.Windows.Forms.MessageBox]::Show(("Update gagal: {0}" -f $_.Exception.Message), "Auto Update") | Out-Null
        return $false
    } finally {
        Remove-Item -Path $tmpRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function RunUpdateCheck([switch]$Silent) {
    $info = GetUpdateInfo
    if (-not $info) {
        # Jika URL manifest kosong/belum diisi, diam saja (jangan popup) kecuali user klik manual
        if (-not $Silent) {
            $manifestUrl = (GetEnvValue "UPDATE_MANIFEST_URL" "").Trim()
            if (-not $manifestUrl) {
                [System.Windows.Forms.MessageBox]::Show("UPDATE_MANIFEST_URL belum diisi di Env Settings.", "Auto Update") | Out-Null
            } else {
                [System.Windows.Forms.MessageBox]::Show("Manifest tidak dapat diakses atau tidak valid.", "Auto Update") | Out-Null
            }
        }
        return
    }

    if (-not $info.has_update) {
        Log ("Version up-to-date ({0})" -f $info.local_version)
        if (-not $Silent) {
            [System.Windows.Forms.MessageBox]::Show(("Tidak ada update. Versi saat ini: {0}" -f $info.local_version), "Auto Update") | Out-Null
        }
        return
    }

    $msg = "Update tersedia."
    if ($info.force) {
        $msg += " (WAJIB)"
    }
    $msg += "`r`n`r`nCurrent: $($info.local_version)`r`nLatest: $($info.remote_version)"
    if ($info.notes) {
        $msg += "`r`n`r`nNotes:`r`n$($info.notes)"
    }

    if ($info.force) {
        # Force update: tidak ada pilihan, langsung apply
        $msg += "`r`n`r`nUpdate ini wajib diinstal sekarang."
        [System.Windows.Forms.MessageBox]::Show(
            $msg,
            "Auto Update - WAJIB",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        ApplyUpdatePackage -zipUrl $info.zip_url -remoteVersion $info.remote_version | Out-Null
    } else {
        $msg += "`r`n`r`nInstall update sekarang?"
        $confirm = [System.Windows.Forms.MessageBox]::Show(
            $msg,
            "Auto Update",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
            ApplyUpdatePackage -zipUrl $info.zip_url -remoteVersion $info.remote_version | Out-Null
        }
    }
}

function RunCloudflareSetupWizard() {
    if (-not (EnsureServerReady)) { return }
    if (-not (EnsureEnvFile)) {
        [System.Windows.Forms.MessageBox]::Show(".env tidak ditemukan dan .env.example juga tidak ada.", "Cloudflare Setup") | Out-Null
        return
    }

    Log "Cloudflare setup: cek login (mohon tunggu)..."
    [System.Windows.Forms.Application]::DoEvents()
    $isLoggedIn = TryWranglerWhoAmI
    if (-not $isLoggedIn) {
        $doLogin = [System.Windows.Forms.MessageBox]::Show(
            "Belum login Wrangler. Buka browser untuk login Cloudflare sekarang?",
            "Cloudflare Setup",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($doLogin -ne [System.Windows.Forms.DialogResult]::Yes) {
            Log "Setup dibatalkan (belum login Wrangler)"
            return
        }
        Log "Membuka wrangler login di browser..."
        [System.Windows.Forms.Application]::DoEvents()
        # non-blocking: buka browser, UI tetap jalan
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "npx wrangler login" -WorkingDirectory $ServerDir -WindowStyle Normal
        [System.Windows.Forms.MessageBox]::Show(
            "Selesaikan login di browser yang sudah terbuka, lalu klik OK di sini.",
            "Cloudflare Login",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        Log "Verifikasi login (mohon tunggu)..."
        [System.Windows.Forms.Application]::DoEvents()
        if (-not (TryWranglerWhoAmI)) {
            [System.Windows.Forms.MessageBox]::Show("Login Wrangler gagal atau belum selesai.", "Cloudflare Setup") | Out-Null
            Log "Wrangler login gagal"
            return
        }
    }

    $currentProject = GetEnvValue "CLOUDFLARE_PAGES_PROJECT" "your-dashboard"
    $currentBranch  = GetEnvValue "CLOUDFLARE_PAGES_BRANCH" "production"

    $project = (PromptText "Isi Cloudflare Pages project name:" "Cloudflare Setup" $currentProject).Trim()
    if (-not $project) {
        Log "Setup dibatalkan (project kosong)"
        return
    }

    $branch = (PromptText "Isi branch deploy Pages:" "Cloudflare Setup" $currentBranch).Trim()
    if (-not $branch) { $branch = "production" }

    $dashDefault = "https://$project.pages.dev/dashboard.html"
    $dashPrompt = (PromptText "Isi Dashboard URL (boleh custom domain). Kosong = default $dashDefault" "Cloudflare Setup" $script:DashboardUrl).Trim()
    if (-not $dashPrompt) { $dashPrompt = $dashDefault }
    $dashNormalized = NormalizeDashboardUrl $dashPrompt

    SetEnvValue "CLOUDFLARE_PAGES_PROJECT" $project
    SetEnvValue "CLOUDFLARE_PAGES_BRANCH" $branch
    SetEnvValue "AUTO_DEPLOY_ON_PUBLIC_CHANGE" "true"

    $script:DashboardUrl = $dashNormalized
    $txtDashboard.Text = $script:DashboardUrl
    SaveLauncherConfig
    RefreshShareLabel

    Log "Test deploy ke Cloudflare (mohon tunggu, bisa 30-60 detik)..."
    [System.Windows.Forms.Application]::DoEvents()
    $localProject = $project
    $localBranch  = $branch
    $localDir     = $ServerDir
    $deployJob = Start-Job -ScriptBlock {
        param($dir, $proj, $br)
        Set-Location $dir
        $out = cmd /c "npx wrangler pages deploy public --project-name `"$proj`" --branch `"$br`" --commit-dirty=true 2>&1"
        [pscustomobject]@{ ExitCode = $LASTEXITCODE; Output = $out }
    } -ArgumentList $localDir, $localProject, $localBranch
    WaitJobWithDoEvents $deployJob
    $deployResult = Receive-Job $deployJob -ErrorAction SilentlyContinue
    Remove-Job $deployJob -Force -ErrorAction SilentlyContinue

    if (-not $deployResult -or $deployResult.ExitCode -ne 0) {
        [System.Windows.Forms.MessageBox]::Show("Test deploy gagal. Cek project/branch dan izin akun Cloudflare.", "Cloudflare Setup") | Out-Null
        Log "Test deploy gagal"
        return
    }

    $preview = ""
    foreach ($line in $deployResult.Output) {
        if ($line -match 'https://[a-z0-9-]+\.[a-z0-9-]+\.pages\.dev') {
            $preview = $matches[0]
        }
    }

    $restartNode = [System.Windows.Forms.MessageBox]::Show(
        "Setup selesai. Restart Node server sekarang agar env baru aktif?",
        "Cloudflare Setup",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($restartNode -eq [System.Windows.Forms.DialogResult]::Yes) {
        Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force
        $script:NodeProc = Start-Process node -ArgumentList "server.js" -WorkingDirectory $ServerDir -PassThru -WindowStyle Hidden
    }

    if ($preview) {
        Log "Setup OK -> $preview"
    } else {
        Log "Setup OK -> deploy berhasil"
    }
}

function SaveLauncherConfig() {
    $cfg = [ordered]@{
        dashboard_url = $script:DashboardUrl
        server_override = $script:ServerOverride
    }
    ($cfg | ConvertTo-Json) | Set-Content -Path $ConfigFile -Encoding ASCII
}

function NormalizeDashboardUrl([string]$candidate) {
    if ([string]::IsNullOrWhiteSpace($candidate)) { return $DefaultDashboardUrl }

    $trimmed = $candidate.Trim().TrimEnd('/')
    try {
        $uri = [System.Uri]$trimmed
    } catch {
        return $DefaultDashboardUrl
    }

    if ($uri.Scheme -ne 'http' -and $uri.Scheme -ne 'https') {
        return $DefaultDashboardUrl
    }

    # Blok URL forge agar launcher tidak nyasar ke halaman login MQL5 Forge.
    if ($uri.Host -match '(^|\.)forge\.mql5\.io$') {
        return $DefaultDashboardUrl
    }

    # Jika user isi domain root tanpa path, defaultkan ke /dashboard.html
    if ([string]::IsNullOrWhiteSpace($uri.AbsolutePath) -or $uri.AbsolutePath -eq '/') {
        return ($trimmed + '/dashboard.html')
    }

    return $trimmed
}

function LoadLauncherConfig() {
    if (-not (Test-Path $ConfigFile)) { return }
    try {
        $raw = Get-Content -Path $ConfigFile -Raw
        if ([string]::IsNullOrWhiteSpace($raw)) { return }
        $cfg = $raw | ConvertFrom-Json
        if ($cfg.dashboard_url -and ($cfg.dashboard_url -is [string])) {
            $script:DashboardUrl = NormalizeDashboardUrl $cfg.dashboard_url
        }
        if ($cfg.server_override -and ($cfg.server_override -is [string])) {
            $script:ServerOverride = $cfg.server_override.Trim()
        }
    } catch {
        Log "Config rusak, pakai default"
    }
}

function GetDashboardLink() {
    $server = ""
    if ($script:ServerOverride) {
        $server = $script:ServerOverride
    } elseif ($script:TunnelUrl) {
        $server = $script:TunnelUrl
    }

    if ($server) {
        $enc = [System.Uri]::EscapeDataString($server)
        return ("{0}?server={1}" -f $script:DashboardUrl, $enc)
    }
    return $script:DashboardUrl
}

function RefreshShareLabel() {
    $share = GetDashboardLink
    if ($share.Length -gt 70) {
        $lblShareUrl.Text = "Share: " + $share.Substring(0, 67) + "..."
    } else {
        $lblShareUrl.Text = "Share: " + $share
    }
}

function OpenBrowserUrl($url) {
    try {
        Start-Process $url | Out-Null
        return $true
    } catch {
        try {
            Start-Process "cmd.exe" -ArgumentList "/c", "start", "", $url -WindowStyle Hidden | Out-Null
            return $true
        } catch {
            return $false
        }
    }
}

function BuildApiBaseUrl([string]$serverUrl) {
    if ([string]::IsNullOrWhiteSpace($serverUrl)) { return "" }
    $base = $serverUrl.Trim().TrimEnd('/')
    if ($base -match '/api$') { return $base }
    return ($base + '/api')
}

function GetStableCommonApiBase([string]$serverUrl) {
    $overrideBase = BuildApiBaseUrl $script:ServerOverride
    if (-not [string]::IsNullOrWhiteSpace($overrideBase)) {
        return $overrideBase
    }

    # Common Files dibaca oleh terminal MT5 di mesin yang sama.
    # Pakai endpoint lokal yang stabil agar restart trycloudflare tidak memaksa update whitelist lagi.
    return 'http://localhost:3000/api'
}

function PublishCommonApiBase([string]$serverUrl) {
    $apiBase = GetStableCommonApiBase $serverUrl
    if ([string]::IsNullOrWhiteSpace($apiBase)) { return }
    try {
        New-Item -ItemType Directory -Path $CommonFilesDir -Force | Out-Null
        Set-Content -Path $CommonApiFile -Value $apiBase -Encoding ASCII
    } catch {
        # Jangan ganggu UX kalau write common file gagal.
    }
}

function EnsureTunnelReady() {
    if ($script:ServerOverride) {
        return $true
    }

    $alive = (Get-Process -Name cloudflared -ErrorAction SilentlyContinue) -ne $null
    if (-not $alive) {
        if (-not (Test-Path $CloudflaredExe)) {
            Log "cloudflared.exe tidak ditemukan"
            return $false
        }
        Remove-Item $LogFile -ErrorAction SilentlyContinue
        $script:TunnelProc = Start-Process $CloudflaredExe -ArgumentList "tunnel --url http://localhost:3000 --logfile `"$LogFile`"" -PassThru -WindowStyle Hidden
        Log "Tunnel auto-start..."
    }

    # Tunggu URL tunnel siap (maks ~8 detik)
    for ($i = 0; $i -lt 12; $i++) {
        if (Test-Path $LogFile) {
            $line = Get-Content $LogFile -Tail 80 | Select-String 'https://[a-z0-9\-]+\.trycloudflare\.com' | Select-Object -Last 1
            if ($line -and ($line -match 'https://[a-z0-9\-]+\.trycloudflare\.com')) {
                $script:TunnelUrl = $matches[0]
                $script:LastTunnelUrl = $script:TunnelUrl
                $lblTunnelUrl.Text = "URL: $($script:TunnelUrl)"
                $lblTunnelUrl.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
                RefreshShareLabel
                Set-Content -Path $ShareFile -Value (GetDashboardLink) -Encoding ASCII
                PublishCommonApiBase $script:TunnelUrl
                return $true
            }
        }
        Start-Sleep -Milliseconds 650
    }

    return (-not [string]::IsNullOrWhiteSpace($script:TunnelUrl))
}

function EnsureServerReady() {
    if ($script:DepsReady) { return $true }

    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show("Node.js belum terinstall. Install dulu dari https://nodejs.org", "Node.js Required") | Out-Null
        return $false
    }

    if (-not (Get-Command npm -ErrorAction SilentlyContinue) -and -not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show("npm tidak ditemukan. Re-install Node.js LTS.", "npm Required") | Out-Null
        return $false
    }

    $envFile = Join-Path $ServerDir ".env"
    $envExample = Join-Path $ServerDir ".env.example"
    if (-not (Test-Path $envFile) -and (Test-Path $envExample)) {
        Copy-Item $envExample $envFile -Force
        Log ".env belum ada -> dibuat otomatis dari .env.example"
    }

    $nodeModules = Join-Path $ServerDir "node_modules"
    if (-not (Test-Path $nodeModules)) {
        Log "Install dependency dulu (npm install)..."
        $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "npm install --no-audit --no-fund" -WorkingDirectory $ServerDir -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -ne 0) {
            [System.Windows.Forms.MessageBox]::Show("npm install gagal. Cek koneksi internet / npm cache.", "Install Error") | Out-Null
            Log "npm install gagal"
            return $false
        }
        Log "Install dependency selesai"
    }

    $script:DepsReady = $true
    return $true
}

# Timer: cek tunnel URL dari log
LoadLauncherConfig
$txtDashboard.Text = $script:DashboardUrl
$txtServerOverride.Text = $script:ServerOverride

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
    # Cek Node
    $nodeAlive = $false
    if ($script:NodeProc -and !$script:NodeProc.HasExited) { $nodeAlive = $true }
    else {
        $nodeAlive = (Get-Process -Name node -ErrorAction SilentlyContinue) -ne $null
    }
    SetDot $dotNode $nodeAlive
    $lblNodeStatus.Text    = if($nodeAlive) { "Status: RUNNING" }  else { "Status: Stopped" }
    $lblNodeStatus.ForeColor = if($nodeAlive) { [System.Drawing.Color]::LimeGreen } else { [System.Drawing.Color]::OrangeRed }

    # Cek Tunnel + ambil URL dari log
    $tunnelAlive = $false
    if ($script:TunnelProc -and !$script:TunnelProc.HasExited) { $tunnelAlive = $true }
    else {
        $tunnelAlive = (Get-Process -Name cloudflared -ErrorAction SilentlyContinue) -ne $null
    }
    SetDot $dotTunnel $tunnelAlive

    if ($tunnelAlive -and (Test-Path $LogFile)) {
        $line = Get-Content $LogFile -Tail 50 | Select-String 'trycloudflare\.com' | Select-Object -Last 1
        if ($line -match 'https://[a-z0-9\-]+\.trycloudflare\.com') {
            $script:TunnelUrl = $matches[0]
            $lblTunnelUrl.Text = "URL: $($script:TunnelUrl)"
            $lblTunnelUrl.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
            RefreshShareLabel

            if ($script:TunnelUrl -ne $script:LastTunnelUrl) {
                $script:LastTunnelUrl = $script:TunnelUrl
                $shareUrl = GetDashboardLink
                $copied = TrySetClipboard $shareUrl
                Set-Content -Path $ShareFile -Value $shareUrl -Encoding ASCII
                PublishCommonApiBase $script:TunnelUrl
                if ($copied) {
                    Log "Tunnel URL berubah -> link terbaru otomatis di-copy"
                } else {
                    Log "Tunnel URL berubah -> link disimpan (clipboard sedang dipakai app lain)"
                }
            }
        }
    }
    if (-not $tunnelAlive) {
        $lblTunnelUrl.Text = "URL: (belum aktif)"
        $lblTunnelUrl.ForeColor = [System.Drawing.Color]::FromArgb(100,180,255)
        $script:TunnelUrl = ""
        $script:LastTunnelUrl = ""
        RefreshShareLabel
    }

    if (-not $script:AutoUpdateChecked) {
        $script:AutoUpdateChecked = $true
        $autoUpdate = ParseBool (GetEnvValue "AUTO_UPDATE_ENABLED" "true") $true
        if ($autoUpdate) {
            RunUpdateCheck -Silent
        }
    }
})
$timer.Start()

# Button handlers
$btnStartNode.Add_Click({
    if (Get-Process -Name node -ErrorAction SilentlyContinue) { Log "Server sudah berjalan"; return }
    if (-not (EnsureServerReady)) { return }
    $script:NodeProc = Start-Process node -ArgumentList "server.js" -WorkingDirectory $ServerDir -PassThru -WindowStyle Hidden
    Log "Server started (PID $($script:NodeProc.Id))"
})

$btnStopNode.Add_Click({
    Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force
    $script:NodeProc = $null
    Log "Server stopped"
})

$btnStartTunnel.Add_Click({
    if (Get-Process -Name cloudflared -ErrorAction SilentlyContinue) { Log "Tunnel sudah berjalan"; return }
    if (-not (Test-Path $CloudflaredExe)) { [System.Windows.Forms.MessageBox]::Show("cloudflared.exe tidak ditemukan!","Error"); return }
    # Hapus log lama agar URL bisa dibaca ulang
    Remove-Item $LogFile -ErrorAction SilentlyContinue
    $script:TunnelProc = Start-Process $CloudflaredExe -ArgumentList "tunnel --url http://localhost:3000 --logfile `"$LogFile`"" -PassThru -WindowStyle Hidden
    Log "Tunnel starting... (tunggu ~5 detik untuk URL muncul)"
})

$btnStopTunnel.Add_Click({
    Get-Process -Name cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force
    $script:TunnelProc = $null
    $script:TunnelUrl  = ""
    Log "Tunnel stopped"
})

$btnOpen.Add_Click({
    if (-not (EnsureTunnelReady)) {
        Log "Tunnel belum siap. Coba Start Tunnel dulu."
        return
    }
    $url = GetDashboardLink
    if (OpenBrowserUrl $url) {
        Log ("Membuka browser: {0}" -f $url)
    } else {
        Log "Gagal buka browser. Link disimpan ke file latest-dashboard-link.txt"
        Set-Content -Path $ShareFile -Value $url -Encoding ASCII
    }
})

$btnCopy.Add_Click({
    if (-not (EnsureTunnelReady)) {
        Log "Tunnel belum siap. Coba Start Tunnel dulu."
        return
    }
    $url = GetDashboardLink
    $copied = TrySetClipboard $url
    Set-Content -Path $ShareFile -Value $url -Encoding ASCII
    if ($copied) {
        Log "URL disalin ke clipboard!"
    } else {
        Log "Clipboard gagal (sedang dipakai). Link tetap disimpan ke file."
    }
})

$btnSaveSettings.Add_Click({
    $dash = $txtDashboard.Text.Trim()
    if (-not $dash) {
        [System.Windows.Forms.MessageBox]::Show("Dashboard URL tidak boleh kosong", "Input Error") | Out-Null
        return
    }
    if (-not ($dash -match '^https?://')) {
        [System.Windows.Forms.MessageBox]::Show("Dashboard URL harus diawali http:// atau https://", "Input Error") | Out-Null
        return
    }

    $ovr = $txtServerOverride.Text.Trim()
    if ($ovr -and -not ($ovr -match '^https?://')) {
        [System.Windows.Forms.MessageBox]::Show("Server Override harus diawali http:// atau https://", "Input Error") | Out-Null
        return
    }

    $normalizedDash = NormalizeDashboardUrl $dash
    if ($normalizedDash -ne $dash.TrimEnd('/')) {
        [System.Windows.Forms.MessageBox]::Show("Dashboard URL dinormalisasi menjadi: $normalizedDash", "Domain Guard") | Out-Null
    }

    $script:DashboardUrl = $normalizedDash
    $script:ServerOverride = $ovr.TrimEnd('/')
    $txtDashboard.Text = $script:DashboardUrl
    SaveLauncherConfig
    RefreshShareLabel
    if ($script:ServerOverride) {
        PublishCommonApiBase $script:ServerOverride
    }
    Log "Domain settings tersimpan"
})

$btnClearOverride.Add_Click({
    $script:ServerOverride = ""
    $txtServerOverride.Text = ""
    SaveLauncherConfig
    RefreshShareLabel
    Log "Server override dihapus"
})

$btnCloudflareSetup.Add_Click({
    RunCloudflareSetupWizard
})

$btnEnvSettings.Add_Click({
    ShowEnvSettingsPanel
})

$btnCheckUpdate.Add_Click({
    RunUpdateCheck
})

$lnkGuide.Add_LinkClicked({
    ShowGuidePanel
    Log "Membuka panel panduan"
})

RefreshShareLabel

$form.Add_FormClosing({
    param($sender, $e)
    $timer.Stop()

    $hasNode    = (Get-Process -Name node          -ErrorAction SilentlyContinue) -ne $null
    $hasTunnel  = (Get-Process -Name cloudflared   -ErrorAction SilentlyContinue) -ne $null

    if ($hasNode -or $hasTunnel) {
        $msg = "Server/tunnel masih berjalan. Hentikan sebelum keluar?"
        $result = [System.Windows.Forms.MessageBox]::Show(
            $msg, "Keluar",
            [System.Windows.Forms.MessageBoxButtons]::YesNoCancel,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($result -eq [System.Windows.Forms.DialogResult]::Cancel) {
            $e.Cancel = $true
            $timer.Start()
            return
        }
        if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
            Get-Process -Name node        -ErrorAction SilentlyContinue | Stop-Process -Force
            Get-Process -Name cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force
            $script:NodeProc   = $null
            $script:TunnelProc = $null
        }
        # No = keluar tapi biarkan proses tetap jalan
    }
})

# Run
[System.Windows.Forms.Application]::Run($form)
