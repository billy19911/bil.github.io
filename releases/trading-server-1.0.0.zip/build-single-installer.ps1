#Requires -Version 5.1
$ErrorActionPreference = 'Stop'

$baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcherPs1 = Join-Path $baseDir 'start-dashboard.ps1'
$launcherExe = Join-Path $baseDir 'XAU-Dashboard-Launcher.exe'
$installerScript = Join-Path $baseDir 'installer\install.ps1'
$outExe = Join-Path $baseDir 'XAU-Dashboard-Setup.exe'

if (-not (Test-Path $launcherPs1)) {
    throw 'start-dashboard.ps1 tidak ditemukan.'
}
if (-not (Test-Path $installerScript)) {
    throw 'installer\install.ps1 tidak ditemukan.'
}

if (-not (Test-Path $launcherExe)) {
    Write-Host 'Launcher EXE belum ada, build dulu...' -ForegroundColor Yellow
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $baseDir 'build-launcher-exe.ps1')
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $launcherExe)) {
        throw 'Gagal build launcher EXE.'
    }
}

$stageRoot = Join-Path $env:TEMP ('xau-installer-' + [guid]::NewGuid().ToString('N'))
$appStage = Join-Path $stageRoot 'app'
$packageDir = Join-Path $stageRoot 'package'
New-Item -ItemType Directory -Path $appStage -Force | Out-Null
New-Item -ItemType Directory -Path $packageDir -Force | Out-Null

# Package runtime files (exclude local secrets/cache/dev artifacts)
$null = robocopy $baseDir $appStage /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XD node_modules .git .wrangler update-feed installer /XF .env launcher-config.json latest-dashboard-link.txt npm-install.log *.tmp *.log
if ($LASTEXITCODE -ge 8) {
    throw ('Gagal menyiapkan package app (robocopy code {0})' -f $LASTEXITCODE)
}

# Ensure launcher exe and installer script are included
Copy-Item -Path $launcherExe -Destination (Join-Path $appStage 'XAU-Dashboard-Launcher.exe') -Force

$payloadZip = Join-Path $packageDir 'payload.zip'
Compress-Archive -Path (Join-Path $appStage '*') -DestinationPath $payloadZip -Force
Copy-Item -Path $installerScript -Destination (Join-Path $packageDir 'install.ps1') -Force

$sedPath = Join-Path $stageRoot 'xau-installer.sed'
$pkgEsc = $packageDir.Replace('\', '\\')
$outEsc = $outExe.Replace('\', '\\')
$sed = @"
[Version]
Class=IEXPRESS
SEDVersion=3

[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=1
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=
DisplayLicense=
FinishMessage=XAU Dashboard berhasil diinstall.
TargetName=$outEsc
FriendlyName=XAU Dashboard Setup
AppLaunched=powershell.exe -NoProfile -ExecutionPolicy Bypass -File install.ps1
PostInstallCmd=<None>
AdminQuietInstCmd=
UserQuietInstCmd=
SourceFiles=SourceFiles

[Strings]
FILE0=payload.zip
FILE1=install.ps1

[SourceFiles]
SourceFiles0=$pkgEsc

[SourceFiles0]
%FILE0%=
%FILE1%=
"@
Set-Content -Path $sedPath -Value $sed -Encoding ASCII

$iexpress = Join-Path $env:WINDIR 'System32\iexpress.exe'
if (-not (Test-Path $iexpress)) {
    throw 'iexpress.exe tidak ditemukan di sistem.'
}

Write-Host 'Membuat single EXE installer...' -ForegroundColor Yellow
$p = Start-Process -FilePath $iexpress -ArgumentList '/N', $sedPath -Wait -PassThru -WindowStyle Hidden
if ($p.ExitCode -ne 0 -or -not (Test-Path $outExe)) {
    throw 'Gagal membuat installer EXE (IExpress).' 
}

Remove-Item -Path $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Installer berhasil dibuat: $outExe" -ForegroundColor Green
