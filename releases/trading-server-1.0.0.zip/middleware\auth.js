'use strict';

/**
 * API key authentication middleware.
 * Every /api/* route requires the header:  X-API-Key: <your-key>
 */
module.exports = function authenticate(req, res, next) {
  if (!process.env.API_KEY) {
    console.error('FATAL: API_KEY is not set in environment!');
    return res.status(500).json({ error: 'Server misconfigured: API_KEY not set' });
  }

  // Header (EA, REST) atau query param ?k= (SSE dari browser)
  const apiKey = req.headers['x-api-key'] || req.query.k;
  if (!apiKey || apiKey !== process.env.API_KEY) {
    return res.status(401).json({ error: 'Unauthorized: invalid or missing API key' });
  }

  next();
};
