'use strict';

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const auth = require('./middleware/auth');
const sse = require('./sse');

const app = express();
const port = parseInt(process.env.PORT, 10) || 3000;
const pagesProject = process.env.CLOUDFLARE_PAGES_PROJECT || 'mt5-dashboard';
const pagesBranch = process.env.CLOUDFLARE_PAGES_BRANCH || 'production';
const autoDeployOnPublicChange = String(process.env.AUTO_DEPLOY_ON_PUBLIC_CHANGE || 'true').toLowerCase() === 'true';

let deployTimer = null;
let deployInProgress = false;
let lastDeployInfo = {
  ok: null,
  reason: 'not_started',
  at: null,
  preview_url: null,
  message: null
};

function extractPreviewUrl(output) {
  if (!output) return null;
  const m = output.match(/https:\/\/[a-z0-9-]+\.[a-z0-9-]+\.pages\.dev/i);
  return m ? m[0] : null;
}

function deployPages(reason) {
  if (deployInProgress) return;
  deployInProgress = true;
  try {
    const cmd = `npx wrangler pages deploy public --project-name ${pagesProject} --branch ${pagesBranch} --commit-dirty=true`;
    const out = execSync(cmd, { cwd: __dirname, encoding: 'utf-8', stdio: 'pipe', timeout: 120000 });
    lastDeployInfo = {
      ok: true,
      reason,
      at: new Date().toISOString(),
      preview_url: extractPreviewUrl(out),
      message: `deployed to ${pagesProject}/${pagesBranch}`
    };
    console.log(`✓ Cloudflare deploy OK (${reason})`);
  } catch (e) {
    lastDeployInfo = {
      ok: false,
      reason,
      at: new Date().toISOString(),
      preview_url: null,
      message: e.message.split('\n')[0]
    };
    console.log(`Cloudflare deploy failed (${reason}): ${lastDeployInfo.message}`);
  } finally {
    deployInProgress = false;
  }
}

function scheduleDeploy(reason, delayMs = 2500) {
  if (deployTimer) clearTimeout(deployTimer);
  deployTimer = setTimeout(() => {
    deployTimer = null;
    deployPages(reason);
  }, delayMs);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    uptime_sec: Math.round(process.uptime()),
    sse_clients: sse.count(),
    now: new Date().toISOString()
  });
});

app.get('/api/deploy-status', (req, res) => {
  res.json({
    ok: true,
    project: pagesProject,
    branch: pagesBranch,
    auto_deploy_on_public_change: autoDeployOnPublicChange,
    last_deploy: lastDeployInfo
  });
});

// Get current server config (tunnel URL from launcher)
app.get('/api/config', (req, res) => {
  try {
    const latestLinkPath = path.join(__dirname, 'latest-dashboard-link.txt');
    if (fs.existsSync(latestLinkPath)) {
      const fullUrl = fs.readFileSync(latestLinkPath, 'utf-8').trim();
      // Extract server URL from full dashboard URL
      // Format: https://production.your-dashboard.pages.dev/dashboard.html?server=https%3A%2F%2Ftunnel-url.trycloudflare.com
      try {
        const urlObj = new URL(fullUrl);
        const serverParam = urlObj.searchParams.get('server');
        if (serverParam) {
          return res.json({
            ok: true,
            server_url: decodeURIComponent(serverParam),
            full_dashboard_url: fullUrl
          });
        }
      } catch (_) {}
    }
    // Fallback to localhost
    res.json({
      ok: true,
      server_url: process.env.SERVER_URL || 'http://localhost:3000',
      full_dashboard_url: null
    });
  } catch (e) {
    res.json({
      ok: false,
      error: e.message,
      server_url: 'http://localhost:3000'
    });
  }
});

app.get('/api/stream', auth, (req, res) => {
  sse.connect(req, res);

  const keepAlive = setInterval(() => {
    try {
      res.write('event: ping\ndata: {}\n\n');
    } catch (_) {
      clearInterval(keepAlive);
    }
  }, 15000);

  req.on('close', () => clearInterval(keepAlive));
});

app.use('/api/status', require('./routes/status'));
app.use('/api/signal', require('./routes/signal'));
app.use('/api/report', require('./routes/report'));
app.use('/api/toggle', require('./routes/toggle'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/accounts', require('./routes/accounts'));
app.use('/api/test', require('./routes/test'));
app.use('/api/git', require('./routes/git'));

app.get('/', (req, res) => {
  res.redirect('/dashboard.html');
});

app.listen(port, () => {
  console.log(`Trading Server -> http://localhost:${port}`);

  // Startup deploy
  setTimeout(() => deployPages('startup'), 4000);

  // Watch file public/* and auto deploy to Cloudflare when changed.
  if (autoDeployOnPublicChange) {
    const publicDir = path.join(__dirname, 'public');
    try {
      fs.watch(publicDir, { recursive: true }, (eventType, filename) => {
        if (!filename) return;
        const lower = String(filename).toLowerCase();
        if (lower.includes('dashboard') || lower.endsWith('.html') || lower.endsWith('.css') || lower.endsWith('.js')) {
          scheduleDeploy(`public_change:${filename}`);
        }
      });
      console.log('✓ Auto deploy watcher aktif untuk folder public/');
    } catch (e) {
      console.log('Auto deploy watcher gagal aktif:', e.message);
    }
  }
});
